
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <limits>
#include <fstream>
#include <iostream>
#include <iomanip>
using datetime=long long;
struct MqlRates {datetime time;double open,high,low,close;};
const double EMPTY_VALUE=std::numeric_limits<double>::max();
template<class T>void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
template<class T>T MathMax(T a,T b){return std::max(a,b);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
double MathAbs(double v){return std::abs(v);}
#ifndef JTC_TURN_CORE_MQH
#define JTC_TURN_CORE_MQH
// Pure causal core: shift >=1, pivot=shift+1; no forming/future bar reads.
struct JTC_TURN_FRAME
{
   bool valid;
   datetime bar_time;
   datetime pivot_time;
   double close_price;
   double high_price;
   double low_price;
   double pivot_close;
   double pivot_high;
   double pivot_low;
   double prior_low;
   double prior_high;
   double atr14;
   double raw_step_r;
   double wave_step_r;
   double raw_delta_pressure;
   double delta_step_norm;
   double long_divergence_r;
   double short_divergence_r;
};
struct JTC_TURN_RESULT
{
   int side;
   int long_score;
   int short_score;
   bool low_candidate;
   bool high_candidate;
   bool long_divergence;
   bool short_divergence;
   double distance_r;
   double pivot_price;
};
bool JTC_TurnFinite(const double v)
{
   return v!=EMPTY_VALUE && MathIsValidNumber(v);
}
void JTC_TurnBuildFrame(const std::vector<MqlRates> &r,const std::vector<double> &raw,
                       const std::vector<double> &wave,const std::vector<double> &delta,
                       const std::vector<double> &ema,const std::vector<double> &volume,
                       const int shift,const int left_bars,JTC_TURN_FRAME &f)
{
   ZeroMemory(f);
   if(shift<1 || left_bars<2 || left_bars>12) return;
   const int last=shift+MathMax(14,left_bars+1);
   if(ArraySize(r)<=last || ArraySize(raw)<=last || ArraySize(wave)<=shift+1 ||
      ArraySize(delta)<=shift || ArraySize(ema)<=shift+1 || ArraySize(volume)<=shift+1) return;
   for(int j=shift;j<=last;j++)
   {
      if(r[j].time<=0 || !JTC_TurnFinite(r[j].high) || !JTC_TurnFinite(r[j].low) ||
         !JTC_TurnFinite(r[j].close) || r[j].high<r[j].low ||
         r[j].close<r[j].low || r[j].close>r[j].high) return;
      if(j<last && r[j].time-r[j+1].time!=180) return;
   }
   for(int j=shift;j<=shift+1;j++)
      if(!JTC_TurnFinite(raw[j]) || !JTC_TurnFinite(wave[j]) ||
         !JTC_TurnFinite(ema[j]) || !JTC_TurnFinite(volume[j]) || volume[j]<=0.0) return;
   if(!JTC_TurnFinite(delta[shift])) return;
   int prior_low_idx=shift+2,prior_high_idx=shift+2;
   for(int j=shift+3;j<=shift+left_bars+1;j++)
   {
      // Strict comparisons keep the most recent extreme on equal prices.
      if(r[j].low<r[prior_low_idx].low) prior_low_idx=j;
      if(r[j].high>r[prior_high_idx].high) prior_high_idx=j;
   }
   if(!JTC_TurnFinite(raw[prior_low_idx]) || !JTC_TurnFinite(raw[prior_high_idx])) return;
   double tr=0.0;
   for(int j=shift;j<shift+14;j++)
      tr+=MathMax(r[j].high-r[j].low,
          MathMax(MathAbs(r[j].high-r[j+1].close),MathAbs(r[j].low-r[j+1].close)));
   const double atr=tr/14.0;
   if(!JTC_TurnFinite(atr) || atr<=0.0) return;
   const int p=shift+1;
   f.bar_time=r[shift].time; f.pivot_time=r[p].time;
   f.close_price=r[shift].close; f.high_price=r[shift].high; f.low_price=r[shift].low;
   f.pivot_close=r[p].close; f.pivot_high=r[p].high; f.pivot_low=r[p].low;
   f.prior_low=r[prior_low_idx].low; f.prior_high=r[prior_high_idx].high;
   f.atr14=atr;
   f.raw_step_r=(raw[shift]-raw[p])/atr;
   f.wave_step_r=(wave[shift]-wave[p])/atr;
   f.raw_delta_pressure=delta[shift]/volume[shift];
   f.delta_step_norm=(ema[shift]-ema[p])/((volume[shift]+volume[p])*0.5);
   f.long_divergence_r=(raw[p]-raw[prior_low_idx])/atr;
   f.short_divergence_r=(raw[prior_high_idx]-raw[p])/atr;
   f.valid=true;
}
void JTC_TurnDecide(const JTC_TURN_FRAME &f,const bool require_divergence,
                   const double min_rebound,const double max_distance,
                   const double momentum_deadzone,JTC_TURN_RESULT &q)
{
   ZeroMemory(q);
   if(!f.valid || !JTC_TurnFinite(f.atr14) || f.atr14<=0.0 || min_rebound<0.0 || max_distance<min_rebound || momentum_deadzone<0.0) return;
   const double ld=(f.close_price-f.pivot_low)/f.atr14;
   const double sd=(f.pivot_high-f.close_price)/f.atr14;
   q.low_candidate=(f.pivot_low<=f.prior_low && f.low_price>f.pivot_low &&
      f.close_price>f.pivot_close && ld>=min_rebound && ld<=max_distance);
   q.high_candidate=(f.pivot_high>=f.prior_high && f.high_price<f.pivot_high &&
      f.close_price<f.pivot_close && sd>=min_rebound && sd<=max_distance);
   q.long_divergence=(f.long_divergence_r>momentum_deadzone);
   q.short_divergence=(f.short_divergence_r>momentum_deadzone);
   const bool dl=(f.raw_delta_pressure>0.0 && f.delta_step_norm>0.0);
   const bool ds=(f.raw_delta_pressure<0.0 && f.delta_step_norm<0.0);
   q.long_score=(f.raw_step_r>momentum_deadzone ? 1 : 0)+
      (f.wave_step_r>momentum_deadzone ? 1 : 0)+(dl ? 1 : 0);
   q.short_score=(f.raw_step_r<-momentum_deadzone ? 1 : 0)+
      (f.wave_step_r<-momentum_deadzone ? 1 : 0)+(ds ? 1 : 0);
   const bool good_long=q.low_candidate && q.long_score==3 &&
      (!require_divergence || q.long_divergence);
   const bool good_short=q.high_candidate && q.short_score==3 &&
      (!require_divergence || q.short_divergence);
   if(good_long==good_short) return; // both/none never invent a direction
   q.side=(good_long ? 1 : -1);
   q.distance_r=(good_long ? ld : sd);
   q.pivot_price=(good_long ? f.pivot_low : f.pivot_high);
}
bool JTC_TurnEmit(const datetime bar,const int side,const int cooldown_bars,
                  datetime &last_long,datetime &last_short)
{
   if(bar<=0 || (side!=1 && side!=-1) || cooldown_bars<1) return false;
   const datetime prior=(side>0 ? last_long : last_short);
   if(prior>0 && bar-prior<(long)cooldown_bars*180) return false;
   if(side>0) last_long=bar; else last_short=bar;
   return true;
}
#endif
#ifndef JTC_TURN_DIRECTION_CORE_MQH
#define JTC_TURN_DIRECTION_CORE_MQH
// Existing SIMPLE_DIRECTION price/MACD-base progress and OFF->ON rule.
// The leg owner is now a confirmed TURN PRE, rather than a legacy WATCH.
struct JTC_TURN_DIRECTION_STATE
{
   datetime last_bar,leg_time,last_event_time;
   int owner_side;
   bool active;
   double prior_high,prior_low;
};
void JTC_TurnDirectionResetState(JTC_TURN_DIRECTION_STATE &s)
{
   ZeroMemory(s);
}
int JTC_TurnDirectionDecide(JTC_TURN_DIRECTION_STATE &s,const datetime bar,
   const bool valid,const int new_turn_side,const double close1,const double close2,
   const double high1,const double high2,const double low1,const double low2,
   const double base1,const double base2)
{
   if(bar<=0 || bar<=s.last_bar) return 0;
   s.last_bar=bar;
   if(!valid)
   {s.owner_side=0;s.leg_time=0;s.active=false;s.prior_high=0.0;s.prior_low=0.0;return 0;}
   if(new_turn_side==1 || new_turn_side==-1)
   {
      s.owner_side=new_turn_side;s.leg_time=bar;s.active=false;
      s.last_event_time=0;s.prior_high=0.0;s.prior_low=0.0;
      return 0; // PRE has priority; no DIRECTION on the same owner bar.
   }
   if(s.owner_side==0 || bar<=s.leg_time) return 0;
   const bool prior=s.last_event_time>s.leg_time;
   const bool aligned=s.owner_side>0 ?
      close1>close2 && high1>high2 && base1>base2 && (!prior || close1>s.prior_high) :
      close1<close2 && low1<low2 && base1<base2 && (!prior || close1<s.prior_low);
   if(!aligned) {s.active=false;return 0;}
   if(s.active) return 0;
   s.active=true;s.last_event_time=bar;s.prior_high=high1;s.prior_low=low1;
   return s.owner_side;
}
#endif

int main(int argc,char**argv){
 if(argc!=3)return 2;
 std::ifstream in(argv[1]);std::vector<MqlRates> cc;std::vector<double> cr,cw,cd,ce,cv,cb;
 MqlRates a;double rm,wm,dm,em,vm,bm;
 while(in>>a.time>>a.open>>a.high>>a.low>>a.close>>rm>>wm>>dm>>em>>vm>>bm){cc.push_back(a);cr.push_back(rm);cw.push_back(wm);cd.push_back(dm);ce.push_back(em);cv.push_back(vm);cb.push_back(bm);}
 int n=cc.size();std::vector<MqlRates> r(n+1);std::vector<double> raw(n+1),wave(n+1),delta(n+1),ema(n+1),volume(n+1),base(n+1);
 for(int i=0;i<n;i++){int k=n-i;r[k]=cc[i];raw[k]=cr[i];wave[k]=cw[i];delta[k]=cd[i];ema[k]=ce[i];volume[k]=cv[i];base[k]=cb[i];}
 datetime ll=0,ls=0;JTC_TURN_DIRECTION_STATE ds;JTC_TurnDirectionResetState(ds);
 std::ofstream out(argv[2]);out<<"index,time,valid,pre_side,dir_side,pivot,atr\n"<<std::setprecision(15);
 for(int i=0;i<n;i++){
  int k=n-i;JTC_TURN_FRAME f;JTC_TURN_RESULT q;
  JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,k,6,f);JTC_TurnDecide(f,true,.15,1.25,.01,q);
  int pre=q.side&&JTC_TurnEmit(r[k].time,q.side,3,ll,ls)?q.side:0;
  bool valid=f.valid&&k+1<=n&&JTC_TurnFinite(base[k])&&JTC_TurnFinite(base[k+1]);
  int direction=0;
  if(k+1<=n)direction=JTC_TurnDirectionDecide(ds,r[k].time,valid,pre,r[k].close,r[k+1].close,r[k].high,r[k+1].high,r[k].low,r[k+1].low,base[k],base[k+1]);
  out<<i<<","<<r[k].time<<","<<f.valid<<","<<pre<<","<<direction<<","<<q.pivot_price<<","<<f.atr14<<"\n";
 }
}
