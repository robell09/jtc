from pathlib import Path
import pandas as pd,numpy as np,json
import simulate as m
saved={n:getattr(m,n) for n in ['B','N','T','OHLC','SPREAD','PRE','DIR','ATR','PIVOT']}
def fixture():
 m.N=8;m.B=pd.DataFrame({'bt':pd.date_range('2026-07-06 12:00',periods=8,freq='3min')});m.T=(m.B.bt.astype('int64')//10**9).to_numpy();m.OHLC=np.tile([100,100.02,99.98,100.],(8,1));m.SPREAD=np.ones(8)*.2;m.PRE=np.zeros(8,dtype=int);m.DIR=np.zeros(8,dtype=int);m.ATR=np.ones(8);m.PIVOT=np.ones(8)*99.5
cases=[]
fixture();m.PRE[0]=1;s,c,cy,curve,o=m.Simulation(m.Config('test',max_add=0)).run();assert len(o)==1 and o.entry_index.iloc[0]==1 and o.fill.iloc[0]==100.2;cases.append('closed-bar causal next-open entry')
fixture();m.PRE[0]=1;m.SPREAD[1]=500;s,c,cy,curve,o=m.Simulation(m.Config('test',max_add=0)).run();assert o.fill.iloc[0]==100.2;cases.append('entry uses already-observed spread, not future closing spread')
fixture();m.PRE[0]=1;m.DIR[0]=1;m.PRE[2]=1;m.DIR[2]=1;m.DIR[4]=1;s,c,cy,curve,o=m.Simulation(m.Config('test',max_add=1)).run();assert len(o)==2 and o.source.tolist()==['PRE','PRE'] and s['adds_DIRECTION']==0;cases.append('PRE priority and shared MAX ADD')
fixture();m.DIR[0]=1;s,*_=m.Simulation(m.Config('test')).run();assert s['total_fills']==0;cases.append('DIRECTION never opens a flat position')
fixture();m.PRE[0]=1;m.PRE[2]=-1;m.PIVOT[2]=100.7;s,c,cy,curve,o=m.Simulation(m.Config('test')).run();assert len(o)==2 and o.side.tolist()==[1,-1] and c.exit_reason.tolist()==['OPPOSITE_PRE'];cases.append('opposite PRE close and reversal ordering')
fixture();m.PRE[0]=1;m.OHLC[2]=[99.,99.02,98.98,99.];s,c,*_=m.Simulation(m.Config('test')).run();assert c.exit_price.iloc[0]==99. and c.exit_phase.iloc[0]=='OPEN_GAP';cases.append('gap stop fills at adverse open, not optimistic stop')
fixture();m.PRE[0]=-1;m.PIVOT[0]=100.7;m.OHLC[2]=[100.,100.3,99.98,100.];s,c,*_=m.Simulation(m.Config('test')).run();assert c.exit_reason.iloc[0]=='SL' and c.exit_price.iloc[0]==100.35;cases.append('short stops use Ask high')
fixture();m.PRE[0]=1;m.DIR[1]=1;m.OHLC[2]=[100.8,100.82,100.78,100.8];m.OHLC[3]=[100.5,100.52,100.48,100.5];s,c,*_=m.Simulation(m.Config('test')).run();assert len(c)==2 and all(c.sl>=c.original_sl) and c.exit_index.tolist()==[3,3];cases.append('ADD shared protection tightens all layers and never widens')
fixture();m.PRE[0]=1;m.DIR[2]=1;s,*_=m.Simulation(m.Config('test',max_total_lots=.03)).run();assert s['total_fills']==1;cases.append('total lot cap')
fixture();m.PRE[0]=1;m.PRE[2]=1;m.DIR[4]=1;s,*_=m.Simulation(m.Config('test',max_add=0)).run();assert s['adds_PRE']==s['adds_DIRECTION']==0;cases.append('MAX ADD zero')
assert m.swap_between(-1,.03,'2026-07-01 20:00','2026-07-02 01:48')==1.54
assert m.swap_between(1,.03,'2026-07-15 23:24','2026-07-16 01:45')==-6.23
assert m.swap_between(-1,.03,'2026-07-03 19:00','2026-07-06 01:00')==.51;cases.append('server rollover, Wednesday triple, weekend swap')
for n,v in saved.items():setattr(m,n,v)
results=pd.read_csv(m.R/'scenario_comparison.csv')
for name in results.name:
 r=m.R/'runs'/name;metrics=json.loads((r/'metrics.json').read_text());o=pd.read_csv(r/'orders.csv');c=pd.read_csv(r/'closed_positions.csv');cy=pd.read_csv(r/'cycles.csv');eq=pd.read_csv(r/'equity.csv')
 assert o.entry_index.is_unique # One fill per bar in all tested paths.
 assert len(o)==metrics['total_fills'] and len(c)==metrics['closed_positions']
 assert round(c.net.sum(),2)==metrics['closed_net']
 assert round(cy.closed_net.sum(),2)==metrics['closed_net']
 assert eq.equity_pnl.iloc[-1]==metrics['end_equity_net']
 assert o.groupby('cycle').apply(lambda d:(d.kind=='ADD').sum(),include_groups=False).max()<=metrics['max_add']
 assert o[o.kind=='INITIAL'].source.eq('PRE').all()
 assert (o.entry_index>=1).all()
 assert metrics['max_lots']<=metrics['lot']*(metrics['max_add']+1)+1e-8
cases.append('all scenarios: fills/cycles/PnL/equity/caps/causal index invariants')
cal=json.loads((m.R/'calibration.json').read_text());assert cal['max_per_position_pnl_error']==cal['max_entry_quote_error']==0;cases.append('original fills and closed PnL exact calibration')
r={'tests_passed':len(cases),'cases':cases,'scenarios_checked':len(results),'M3_OHLC_model_only':True,'MT5_compile_or_real_tick_replay':'NOT_RUN'}
(m.R/'model_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
