from pathlib import Path
import re,subprocess,pandas as pd,numpy as np,hashlib,json,shutil
R=Path(__file__).resolve().parent
E=Path('/workspace/jtc/versions/v8.290/MQL5/Experts/Joon_Trade_Compass_v8_290_M3LightweightTurnAdd')
source=R/'source_snapshot';source.mkdir(exist_ok=True)
for name in ['TurnCore.mqh','TurnDirectionCore.mqh','TurnOrderEngine.mqh','RiskEngine.mqh','PositionManager.mqh','Inputs.mqh']:
 if E.exists():shutil.copyfile(E/name,source/name)
b=pd.read_csv(R/'market_bars.csv');x=b[['m3_open','m3_high','m3_low','m3_close','assist_raw_macd','assist_macd_wave','assist_raw_delta','assist_ema_delta','m3_volume','assist_macd_base']].copy();x.insert(0,'epoch',pd.to_datetime(b.m3_bar_time).astype('int64')//10**9);x.to_csv(R/'signal_input.tsv',sep=' ',index=False,header=False,float_format='%.12g')
core=(source/'TurnCore.mqh').read_text();core=re.sub(r'const (MqlRates|double) &(\w+)\[\]',r'const std::vector<\1> &\2',core)
dircore=(source/'TurnDirectionCore.mqh').read_text()
header=r'''
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <limits>
#include <fstream>
#include <iostream>
#include <iomanip>
using datetime=long long;
struct MqlRates {datetime time;double open,high,low,close;};
const double EMPTY_VALUE=std::numeric_limits<double>::max();
template<class T>void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
template<class T>T MathMax(T a,T b){return std::max(a,b);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
double MathAbs(double v){return std::abs(v);}
'''
body=r'''
int main(int argc,char**argv){
 if(argc!=3)return 2;
 std::ifstream in(argv[1]);std::vector<MqlRates> cc;std::vector<double> cr,cw,cd,ce,cv,cb;
 MqlRates a;double rm,wm,dm,em,vm,bm;
 while(in>>a.time>>a.open>>a.high>>a.low>>a.close>>rm>>wm>>dm>>em>>vm>>bm){cc.push_back(a);cr.push_back(rm);cw.push_back(wm);cd.push_back(dm);ce.push_back(em);cv.push_back(vm);cb.push_back(bm);}
 int n=cc.size();std::vector<MqlRates> r(n+1);std::vector<double> raw(n+1),wave(n+1),delta(n+1),ema(n+1),volume(n+1),base(n+1);
 for(int i=0;i<n;i++){int k=n-i;r[k]=cc[i];raw[k]=cr[i];wave[k]=cw[i];delta[k]=cd[i];ema[k]=ce[i];volume[k]=cv[i];base[k]=cb[i];}
 datetime ll=0,ls=0;JTC_TURN_DIRECTION_STATE ds;JTC_TurnDirectionResetState(ds);
 std::ofstream out(argv[2]);out<<"index,time,valid,pre_side,dir_side,pivot,atr\n"<<std::setprecision(15);
 for(int i=0;i<n;i++){
  int k=n-i;JTC_TURN_FRAME f;JTC_TURN_RESULT q;
  JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,k,6,f);JTC_TurnDecide(f,true,.15,1.25,.01,q);
  int pre=q.side&&JTC_TurnEmit(r[k].time,q.side,3,ll,ls)?q.side:0;
  bool valid=f.valid&&k+1<=n&&JTC_TurnFinite(base[k])&&JTC_TurnFinite(base[k+1]);
  int direction=0;
  if(k+1<=n)direction=JTC_TurnDirectionDecide(ds,r[k].time,valid,pre,r[k].close,r[k+1].close,r[k].high,r[k+1].high,r[k].low,r[k+1].low,base[k],base[k+1]);
  out<<i<<","<<r[k].time<<","<<f.valid<<","<<pre<<","<<direction<<","<<q.pivot_price<<","<<f.atr14<<"\n";
 }
}
'''
(R/'signal_replay.cpp').write_text(header+core+dircore+body)
subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(R/'signal_replay.cpp'),'-o',str(R/'signal_replay')],check=True)
subprocess.run([str(R/'signal_replay'),str(R/'signal_input.tsv'),str(R/'signals.csv')],check=True)
s=pd.read_csv(R/'signals.csv');assert len(s)==len(b)
reference=Path('/workspace/jtc_light_build/package/tests')
if reference.exists():
 a=pd.read_csv(reference/'cpp_signals.csv');assert s.loc[s.pre_side!=0,'index'].tolist()==a['index'].tolist();assert s.loc[s.pre_side!=0,'pre_side'].tolist()==a.side.tolist()
 d=pd.read_csv(reference/'direction_candidates.csv');assert list(zip(s.loc[s.dir_side!=0,'time'],s.loc[s.dir_side!=0,'dir_side']))==list(zip(d.time,d.side))
report={'bars':len(s),'PRE':int((s.pre_side!=0).sum()),'DIRECTION':int((s.dir_side!=0).sum()),'MQL_core_replayed':True,'version':'8.290','hashes':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.iterdir()}}
(R/'signal_replay_validation.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='hashes'}))
