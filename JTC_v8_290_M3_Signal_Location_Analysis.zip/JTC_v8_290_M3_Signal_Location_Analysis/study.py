from pathlib import Path
import pandas as pd,numpy as np,json
R=Path(__file__).resolve().parent
b=pd.read_csv(R/'market_bars.csv');s=pd.read_csv(R/'signals.csv');n=len(b)
o,h,l,c=[b['m3_'+v].to_numpy() for v in ['open','high','low','close']];raw=b.assist_raw_macd.to_numpy();wave=b.assist_macd_wave.to_numpy();de=b.assist_raw_delta.to_numpy();em=b.assist_ema_delta.to_numpy();vol=b.m3_volume.to_numpy();t=pd.to_datetime(b.m3_bar_time);sp=b.spread_points.to_numpy()*.01
atr=pd.concat([pd.Series(h-l),pd.Series(h-c).shift(0)*0+pd.Series(h)-pd.Series(c).shift(),pd.Series(l)-pd.Series(c).shift()],axis=1).abs().max(axis=1).rolling(14).mean().to_numpy()
valid=s.valid.to_numpy().astype(bool)
def cont(a,z):return a>=0 and z<n and (t.iloc[z]-t.iloc[a]).total_seconds()==180*(z-a)
def feats(i,p,side):
 prev=range(p-6,p);prior=min(prev,key=lambda j:l[j]) if side==1 else max(prev,key=lambda j:h[j]);pivot=l[p] if side==1 else h[p]
 ext=l[p]<=l[prior] if side==1 else h[p]>=h[prior]
 hold=np.all(l[p+1:i+1]>l[p]) if side==1 else np.all(h[p+1:i+1]<h[p])
 dist=side*(c[i]-pivot)/atr[i]
 mom=side*(raw[i]-raw[i-1])/atr[i]>.01;wav=side*(wave[i]-wave[i-1])/atr[i]>.01;delta=side*de[i]/vol[i]>0 and side*(em[i]-em[i-1])>0
 div=side*(raw[p]-raw[prior])/atr[i]>.01
 shape=(c[i]-l[i])/(h[i]-l[i]) if side==1 else (h[i]-c[i])/(h[i]-l[i])
 accel=side*(raw[i]-2*raw[i-1]+raw[i-2])/atr[i]>.01
 return ext and hold and side*(c[i]-c[p])>0 and .15<=dist<=1.25,dict(pivot=p,pivot_price=pivot,distance_atr=dist,mom=mom,wave=wav,delta=delta,div=div,shape=shape,accel=accel)
def generate(mode):
 if mode=='current':return [(i,i-1,int(s.pre_side.iloc[i])) for i in range(n) if s.pre_side.iloc[i]!=0]
 out=[];last={1:-100,-1:-100};used=set()
 for i in range(16,n):
  if not valid[i]:continue
  cand=[]
  for side in [1,-1]:
   for k in range(1,4 if mode.startswith('window') else 2):
    p=i-k
    if not cont(p-6,i):continue
    ok,f=feats(i,p,side)
    if not ok:continue
    if mode=='no_divergence':ok=f['mom'] and f['wave'] and f['delta']
    elif mode=='two_of_three':ok=f['div'] and f['delta'] and (f['mom'] or f['wave'])
    elif mode=='raw_delta_only':ok=f['div'] and f['delta'] and f['mom']
    elif mode=='current_shape':ok=f['div'] and f['delta'] and f['mom'] and f['wave'] and f['shape']>=.65
    elif mode in ['window3_strict','strict_rebuilt']:ok=f['div'] and f['delta'] and f['mom'] and f['wave']
    elif mode=='window3_raw_shape':ok=f['delta'] and f['mom'] and f['shape']>=.65
    elif mode=='acceleration':ok=f['div'] and f['delta'] and (f['mom'] or f['accel']) and f['shape']>=.65
    if ok and (side,p) not in used:cand.append((i,p,side));break
  if len(cand)!=1:continue
  i,p,side=cand[0]
  if i-last[side]<3:continue
  out.append((i,p,side));last[side]=i;used.add((side,p))
 return out
assert generate('strict_rebuilt')==generate('current'), 'Baseline reconstruction mismatch'
rows=[]
for mode in ['current','no_divergence','two_of_three','raw_delta_only','current_shape','window3_strict','window3_raw_shape','acceleration']:
 for i,p,side in generate(mode):
  ok,f=feats(i,p,side);x={'variant':mode,'index':i,'pivot_index':p,'side':side,'bar_time':str(t.iloc[i]),'pivot_time':str(t.iloc[p]),'available_time':str(t.iloc[i]+pd.Timedelta(minutes=3)),'month':str(t.iloc[i].month),'confirm_bars':i-p,'distance_atr':f['distance_atr'],'shape':f['shape']}
  for horizon in [3,5,10]:
   if cont(i,i+horizon):
    x[f'return{horizon}_atr']=side*(c[i+horizon]-c[i])/atr[i]
    # Trade opportunity fixed horizon, not EA, opening fee 7/lot, multiplier 100 -> .07 price unit.
    exitspread=sp[i+horizon] if side<0 else 0;entryspread=sp[i] if side>0 else 0
    x[f'net{horizon}_price']=side*((c[i+horizon]+exitspread)-(o[i+1]+entryspread))-.07
  if cont(p,i+5):
   x['survives5']=float(np.all(l[i+1:i+6]>=l[p]) if side>0 else np.all(h[i+1:i+6]<=h[p]))
   x['mfe5_atr']=(max(h[i+1:i+6])-c[i])/atr[i] if side>0 else (c[i]-min(l[i+1:i+6]))/atr[i]
   x['mae5_atr']=(c[i]-min(l[i+1:i+6]))/atr[i] if side>0 else (max(h[i+1:i+6])-c[i])/atr[i]
  rows.append(x)
x=pd.DataFrame(rows);x.to_csv(R/'signal_locations.csv',index=False)
stats=[]
for (v,m,side),g in x.groupby(['variant','month','side']):
 q=g.return5_atr.dropna();cost=g.net5_price.dropna();stats.append({'variant':v,'month':m,'side':side,'signals':len(g),'valid5':len(q),'positive5_pct':round((q>0).mean()*100,2),'pivot_survives5_pct':round(g.survives5.mean()*100,2),'mean_distance_atr':round(g.distance_atr.mean(),3),'mean_confirm_bars':round(g.confirm_bars.mean(),2),'mean_return5_atr':round(q.mean(),3),'mean_net5_price':round(cost.mean(),3)})
pd.DataFrame(stats).to_csv(R/'variant_by_month_side.csv',index=False)
a=[]
for v,g in x.groupby('variant'):
 a.append({'variant':v,'signals':len(g),'valid5':int(g.return5_atr.notna().sum()),'positive5_pct':round((g.return5_atr.dropna()>0).mean()*100,2),'pivot_survives5_pct':round(g.survives5.mean()*100,2),'mean_distance_atr':round(g.distance_atr.mean(),3),'mean_confirm_bars':round(g.confirm_bars.mean(),2),'mean_net5_price':round(g.net5_price.mean(),3),'mean_net10_price':round(g.net10_price.mean(),3)})
pd.DataFrame(a).to_csv(R/'variant_summary.csv',index=False);print(pd.DataFrame(a).to_string(index=False));print(pd.DataFrame(stats).query("variant=='current'").to_string(index=False))
# Retrospective reference extrema. ONLY evaluation labels; future five bars never input to signal.
labels=[]
for p in range(16,n-5):
 if not valid[p] or not cont(p-6,p+5):continue
 for side in [1,-1]:
  ext=(l[p]<min(l[p-6:p]) and l[p]<=min(l[p+1:p+6])) if side>0 else (h[p]>max(h[p-6:p]) and h[p]>=max(h[p+1:p+6]))
  excursion=(max(h[p+1:p+6])-l[p]) if side>0 else (h[p]-min(l[p+1:p+6]))
  if ext and excursion>=atr[p]:labels.append({'pivot_index':p,'side':side,'time':str(t.iloc[p])})
y=pd.DataFrame(labels);y.to_csv(R/'retrospective_extrema_labels.csv',index=False)
coverage=[]
for v,g in x.groupby('variant'):
 pairs=set(zip(g.pivot_index,g.side));hits=sum((p,side) in pairs for p,side in zip(y.pivot_index,y.side));coverage.append({'variant':v,'reference_extrema':len(y),'exact_pivot_matches':hits,'coverage_pct':round(100*hits/len(y),2)})
pd.DataFrame(coverage).to_csv(R/'extrema_coverage.csv',index=False);print(pd.DataFrame(coverage).to_string(index=False))
