from pathlib import Path
import pandas as pd, numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;b=pd.read_csv(R/'market_bars.csv');q=pd.read_csv(R/'signal_locations.csv');cur=q[q.variant=='current'];lab=pd.read_csv(R/'retrospective_extrema_labels.csv');pairs=set(zip(cur.pivot_index,cur.side));miss=lab[[ (p,s) not in pairs for p,s in zip(lab.pivot_index,lab.side)]]
cases=[('Confirmed LOW example',cur[(cur.side==1)&(cur.survives5==1)].sort_values('return5_atr').iloc[-5]),('Failed HIGH example',cur[(cur.side==-1)&(cur.survives5==0)].sort_values('return5_atr').iloc[3]),('Confirmed but far from pivot',cur.sort_values('distance_atr').iloc[-5]),('Missed retrospective LOW (future label)',miss[miss.side==1].iloc[len(miss[miss.side==1])//2])]
fig,axs=plt.subplots(2,2,figsize=(14,8),layout='constrained');examples=[]
for ax,(title,row) in zip(axs.flat,cases):
 p=int(row.pivot_index);i=int(row['index']) if 'index' in row else None;lo=max(0,p-7);hi=min(len(b),p+14);z=b.iloc[lo:hi];xx=np.arange(lo,hi)
 for j in xx:
  a=b.iloc[j];color='#138568' if a.m3_close>=a.m3_open else '#c65050';ax.vlines(j,a.m3_low,a.m3_high,color=color);ax.vlines(j,a.m3_open,a.m3_close,color=color,lw=4)
 side=int(row.side);pivot=b.m3_low.iloc[p] if side>0 else b.m3_high.iloc[p];ax.scatter([p],[pivot],color='#606060',s=65,label='Pivot anchor; known later')
 if i is not None:
  ax.axvline(i+1,color='#a33dc4',ls='--',label='First tradable bar');ax.scatter([i],[b.m3_close.iloc[i]],c='#2255c4',s=60,label='Confirmation bar close')
 ax.axhline(pivot,color='grey',ls=':',alpha=.5);ticks=xx[::3];ax.set_xticks(ticks,[pd.to_datetime(b.m3_bar_time.iloc[j]).strftime('%H:%M') for j in ticks]);ax.set_title(title+'\n'+str(b.m3_bar_time.iloc[p]));ax.legend(fontsize=7);ax.grid(alpha=.15)
 examples.append({'case':title,'pivot_index':p,'confirm_index':i,'pivot_time':str(b.m3_bar_time.iloc[p]),'side':side})
fig.suptitle('M3 signal position audit | examples selected retrospectively for explanation');fig.savefig(R/'signal_position_examples.png',dpi=160);fig.savefig(R/'signal_position_examples.svg');pd.DataFrame(examples).to_csv(R/'chart_examples.csv',index=False)
