import study,json
from pathlib import Path
modes=['no_divergence','two_of_three','raw_delta_only','current_shape','window3_strict','window3_raw_shape','acceleration','strict_rebuilt'];length=study.n
full={m:study.generate(m) for m in modes};checks=0
for cutoff in [1000,5000,10000]:
 study.n=cutoff
 for m in modes:
  assert study.generate(m)==[z for z in full[m] if z[0]<cutoff],(m,cutoff)
  checks+=1
study.n=length
Path(__file__).with_name('causality_validation.json').write_text(json.dumps({'baseline_core_exact_match':True,'prefix_invariance_checks':checks,'cutoffs':[1000,5000,10000],'status':'passed'},indent=2))
print('PASS: baseline replay matches and',checks,'prefix checks')
