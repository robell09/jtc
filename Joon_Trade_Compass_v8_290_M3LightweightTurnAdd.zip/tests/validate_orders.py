from pathlib import Path
import re,subprocess,json,difflib,hashlib
P=Path(__file__).resolve().parents[1]
E=P/'Joon_Trade_Compass_v8_290_M3LightweightTurnAdd'
s=(E/'TurnOrderEngine.mqh').read_text()
s=re.sub(r'^(ulong|bool) (g_turn_order_exit_\w+)\[\];',r'std::vector<\1> \2;',s,flags=re.M)
header=r'''
#include <vector>
#include <string>
#include <cmath>
#include <cstdio>
#include <cassert>
#include <iostream>
using string=std::string;using datetime=long long;using ulong=unsigned long;
const int PERIOD_M3=3,SYMBOL_ASK=1,SYMBOL_BID=2,POSITION_SYMBOL=1,POSITION_MAGIC=2,POSITION_IDENTIFIER=3,TIME_DATE=1,TIME_SECONDS=2;
const int JTA_CYCLE_IDLE=0,JTA_CYCLE_EXIT_PENDING=1,JTA_CYCLE_ENTRY_PENDING=2,JTA_CYCLE_POSITION_OPEN=3;
string _Symbol="GOLD";ulong InpMagicNumber=123;
bool InpTurnAddOnPre=true,InpTurnAddOnDirection=true;
int g_max_additional_entries=0,g_additional_entry_filled_count=0,g_add_same_direction_signal_count=0,adds=0,bars_since=1;
bool g_add_order_in_progress=false,g_add_position_sync_pending=false,add_ok=true;
string g_add_second_signal_event_id;
int BarsSinceLastEntry(){return bars_since;}
bool InpTurnTradeEnabled=true,InpTurnPreEnabled=true,InpTurnReverseOnOpposite=true,InpSystemEnabled=true,g_auto_trading=true;
double InpTurnMinReboundATR=.15,InpTurnMaxDistanceATR=1.25;
bool g_m3_auto_execution_context_active=false,g_m3_auto_order_authority_active=false,g_exit_order_in_progress=false,g_entry_order_in_progress=false;
string g_csv_order_signal_source,g_current_long_signal_event_id,g_current_short_signal_event_id,g_exit_source_event_id,g_status;
int g_csv_order_signal_side=0,g_range_long_signal_count=0,g_range_short_signal_count=0,g_last_long_score=0,g_last_short_score=0;
datetime g_csv_order_signal_time=0;
struct Assist {bool turn_direction_valid=false,turn_direction_signal=false;datetime turn_direction_bar=1000;int turn_direction_side=1;bool turn_pre_data_valid=true,turn_pre_signal=true;datetime turn_pre_confirm_bar=1000,turn_pre_available_time=1180;int turn_pre_side=1;double turn_pre_atr14=1,turn_pre_pivot_price=10;} g_assist_state;
struct Cycle {int state=0;} g_trade_cycle;
datetime latest=1000,now=1180;double ask=10.8,bid=10.7;int held=0,entries=0,exits=0,allowed_side=0;
bool permission=true,close_ok=true,entry_ok=true;
struct Pos{ulong id;string symbol;ulong magic;bool open;};std::vector<Pos> positions;int selected=-1;
string IntegerToString(long v){return std::to_string(v);}string TimeToString(datetime v,int){return std::to_string(v);}
const char* arg(const string& v){return v.c_str();}template<class T>T arg(T v){return v;}
template<class... A>string StringFormat(const char* f,A...a){char b[2048];std::snprintf(b,sizeof(b),f,arg(a)...);return b;}
template<class T>int ArraySize(const std::vector<T>&v){return int(v.size());}
template<class T>void ArrayResize(std::vector<T>&v,int n){v.resize(n);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
datetime iTime(const string&,int,int){return latest;}datetime TimeCurrent(){return now;}
double SymbolInfoDouble(const string&,int what){return what==SYMBOL_ASK?ask:bid;}
int ManagedPositionSide(){return held;}bool AutoDirectionAllows(int side){return allowed_side==0||allowed_side==side;}
bool JTATradePermissionAllowed(string& reason){reason="TRADE_PERMISSION";return permission;}
void Print(const string&){}
template<class...A>void WriteUnifiedOrderSignalAudit(A...){}
void TradeCycleEnsure(int,const string&){g_trade_cycle.state=4;}void TradeCycleClear(const string&){g_trade_cycle.state=0;}
bool EntryEngineSubmitInitial(int side,int score,const string& reason,double price,bool append){
 assert(g_m3_auto_execution_context_active && score==3 && price>0 && !append);
 assert(reason.find("TURN PRE INITIAL")!=string::npos);entries++;
 if(!permission || !entry_ok)return false;
 held=side;g_trade_cycle.state=JTA_CYCLE_POSITION_OPEN;return true;
}
bool EntryEngineSubmitAdditional(int side,int stage,const string& reason){
 assert(g_m3_auto_execution_context_active && reason.find("TURN ADD")!=string::npos);
 assert(stage==g_additional_entry_filled_count+1 && g_add_second_signal_event_id!="");
 adds++;if(!add_ok || !permission)return false;
 g_additional_entry_filled_count++;assert(side==held);return true;
}
bool CloseManagedPosition(const string& reason){
 assert(reason.find("TURN PRE OPPOSITE EXIT")!=string::npos);exits++;
 if(!close_ok)return false;
 for(auto &p:positions)if(p.symbol==_Symbol&&p.magic==InpMagicNumber)p.open=false;
 held=0;g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;g_exit_order_in_progress=true;return true;
}
int PositionsTotal(){return positions.size();}ulong PositionGetTicket(int i){selected=i;return i+1;}
bool PositionSelectByTicket(ulong t){selected=int(t)-1;return selected>=0&&selected<int(positions.size());}
string PositionGetString(int){return positions.at(selected).symbol;}
long PositionGetInteger(int what){return what==POSITION_MAGIC?positions.at(selected).magic:positions.at(selected).id;}
bool DataExportPositionIdentifierOpen(ulong id){for(auto&p:positions)if(p.id==id)return p.open;return false;}
'''
body=r'''
void reset(int side=1){
 JTC_TurnOrderReset();adds=0;bars_since=1;g_max_additional_entries=0;g_additional_entry_filled_count=0;
 g_add_order_in_progress=g_add_position_sync_pending=false;InpTurnAddOnPre=InpTurnAddOnDirection=add_ok=true;g_assist_state=Assist();g_assist_state.turn_pre_side=side;
 if(side<0){g_assist_state.turn_pre_pivot_price=11.5;}
 latest=1000;now=1180;ask=10.8;bid=10.7;held=0;entries=exits=0;allowed_side=0;
 permission=close_ok=entry_ok=true;positions.clear();g_trade_cycle.state=0;
 g_exit_order_in_progress=g_entry_order_in_progress=false;
 g_m3_auto_execution_context_active=false;InpTurnTradeEnabled=InpTurnPreEnabled=InpSystemEnabled=g_auto_trading=InpTurnReverseOnOpposite=true;
}
void ack(ulong id){g_trade_cycle.state=0;g_exit_order_in_progress=false;JTC_TurnOrderOnExitDeal(id);}
int main(){
 int cases=0;
 reset();JTC_TurnOrderProcessTick();assert(entries==1&&held==1&&g_csv_order_signal_source=="TURN_PRE"&&!g_m3_auto_execution_context_active);JTC_TurnOrderProcessTick();assert(entries==1);cases++;
 reset(-1);JTC_TurnOrderProcessTick();assert(entries==1&&held==-1);cases++;
 reset();held=1;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);JTC_TurnOrderProcessTick();assert(entries==0);ack(55);assert(entries==0);JTC_TurnOrderProcessTick();assert(entries==1&&held==1);JTC_TurnOrderProcessTick();assert(entries==1);cases++;
 reset(-1);held=1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==1&&held==-1);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true},{56,"GOLD",123,true},{60,"GOLD",999,true},{61,"WTI",123,true}};JTC_TurnOrderProcessTick();assert(g_turn_order_exit_ids.size()==2);ack(55);JTC_TurnOrderProcessTick();assert(entries==0);ack(56);JTC_TurnOrderProcessTick();assert(entries==1&&positions[2].open&&positions[3].open);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};close_ok=false;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0&&held==-1&&g_turn_order_pending_side==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();positions[0].open=true;held=-1;ack(55);JTC_TurnOrderProcessTick();assert(entries==0&&!g_turn_order_flat_confirmed);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};InpTurnReverseOnOpposite=false;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();latest+=180;ack(55);JTC_TurnOrderProcessTick();assert(entries==0&&g_turn_order_pending_side==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();g_auto_trading=false;ack(55);JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();ack(55);ask=13;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_auto_trading=false;JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpSystemEnabled=false;JTC_TurnOrderProcessTick();InpSystemEnabled=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpTurnPreEnabled=false;JTC_TurnOrderProcessTick();InpTurnPreEnabled=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_signal=false;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();g_assist_state.turn_pre_data_valid=false;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_side=0;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();latest=1180;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();now=1179;JTC_TurnOrderProcessTick();now=1180;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();allowed_side=-1;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};allowed_side=-1;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);cases++;
 reset();held=-1;permission=false;JTC_TurnOrderProcessTick();assert(exits==0&&entries==0);cases++;
 reset();entry_ok=false;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(entries==1&&held==0&&g_trade_cycle.state==0&&!g_m3_auto_execution_context_active);cases++;
 reset();ask=13;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();ask=10.1;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_trade_cycle.state=JTA_CYCLE_ENTRY_PENDING;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_entry_order_in_progress=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpTurnTradeEnabled=false;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();g_assist_state.turn_pre_atr14=std::nan("");JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_pivot_price=std::nan("");JTC_TurnOrderProcessTick();assert(entries==0);cases++;

 reset();held=1;g_max_additional_entries=2;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&entries==0&&g_csv_order_signal_source=="TURN_PRE");cases++;
 reset(-1);held=-1;g_max_additional_entries=2;JTC_TurnOrderProcessTick();assert(adds==1);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&entries==0&&g_csv_order_signal_source=="DIRECTION");cases++;
 reset(-1);held=-1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_side=-1;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==1);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&g_csv_order_signal_source=="TURN_PRE");cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};g_max_additional_entries=2;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;g_assist_state.turn_direction_side=-1;JTC_TurnOrderProcessTick();assert(exits==1&&adds==0);cases++;
 reset();g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0&&entries==0&&exits==0);cases++;
 reset();held=-1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0&&exits==0);cases++;
 reset();held=1;g_max_additional_entries=1;g_additional_entry_filled_count=1;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;add_ok=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&g_additional_entry_filled_count==0);cases++;
 reset();held=1;g_max_additional_entries=2;bars_since=0;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_add_order_in_progress=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_add_position_sync_pending=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;allowed_side=-1;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;InpTurnAddOnPre=false;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;InpTurnAddOnDirection=false;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_auto_trading=false;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;latest=1180;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==1);latest=1180;now=1360;g_assist_state.turn_direction_bar=1180;JTC_TurnOrderProcessTick();assert(adds==2);latest=1360;now=1540;g_assist_state.turn_direction_bar=1360;JTC_TurnOrderProcessTick();assert(adds==2&&g_additional_entry_filled_count==2);cases++;
 std::cout<<cases<<" order-router scenarios passed\n";
}
'''
cpp=P/'tests/order_router_tests.cpp';cpp.write_text(header+s+body)
binary=P/'tests/order_router_tests'
subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(cpp),'-o',str(binary)],check=True)
r=subprocess.run([str(binary)],check=True,text=True,capture_output=True);print(r.stdout)
# Check wiring that the compatibility harness cannot execute.
runtime=(E/'Runtime.mqh').read_text();tick=runtime[runtime.index('void OnTick()'):]
start=tick.index('if(InpTurnTradeEnabled)');end=tick.index('   if(!InpSystemEnabled)',start)
assert 'JTC_TurnOrderProcessTick();' in tick[start:end] and 'return;' in tick[start:end]
assert start<tick.index('ExitEngineManageOpenPositionUnified();')<tick.index('M3AutoEngineProcessTick(true);')
assert 'if(InpTurnTradeEnabled || !M3AutoEngineIsActive())\n         EnsureManagedStopsProtected(false);' in tick
assert runtime.index('TradeCycleClear("POSITION_FULLY_CLOSED")')<runtime.index('JTC_TurnOrderOnExitDeal((ulong)HistoryDealGetInteger(transaction.deal,DEAL_POSITION_ID))')
assert 'g_assist_state.turn_pre_signal=false;' in (E/'M3AutoEngine.mqh').read_text()
assert '"TURN PRE INITIAL"' in (E/'PositionManager.mqh').read_text()
assert 'input bool InpTurnTradeEnabled = true;' in (E/'Inputs.mqh').read_text()
for f in E.glob('*'):
 if f.suffix in {'.mq5','.mqh'}:
  for inc in re.findall(r'^\s*#include "([^"]+)"',f.read_text(),re.M):assert (f.parent/inc).exists(),(f,inc)
result={'order_router_scenarios':52,'result':'PASS','actual_MQL_router_body_executed_in_Cpp_mock_harness':True,'legacy_tick_order_paths_excluded_in_turn_mode':True,'exit_callback_runs_after_cycle_reset':True,'historical_warmup_turn_pulse_cleared':True,'whole_MT5_compile':'NOT_RUN','MT5_strategy_tester':'NOT_RUN'}
(P/'tests/order_validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
old=Path('/workspace/jtc_light_build/base/Joon_Trade_Compass_v8_289_M3LightweightCsvParity')
if old.exists():
 patch=[]
 for f in E.glob('*.mqh'):
  a=(old/f.name).read_text().splitlines(True) if (old/f.name).exists() else []
  patch.extend(difflib.unified_diff(a,f.read_text().splitlines(True),fromfile='v8.289/'+f.name,tofile='v8.290/'+f.name))
 (P/'tests/changes_from_8_289.patch').write_text(''.join(patch))
