
#include <string>
#include <cstdio>
#include <cassert>
#include <iostream>
using string=std::string;
bool tester=false;string _Symbol="GOLD";
bool DataExportIsTester(){return tester;}
string DataExportRunId(){return "20260701_000000_12345_D2982846829_4951";}
string TradeLogSafeFileToken(string s){return s;}
string StringSubstr(string s,int start,int n){return s.substr(start,n);}
const char* fmt(const string& v){return v.c_str();}
template<class T>T fmt(T v){return v;}
template<class...A>string StringFormat(const char* f,A...args){char b[1024];std::snprintf(b,sizeof(b),f,fmt(args)...);return b;}

#define JTC_EA_VERSION "8.290"
string DataExportEaVersion(){ return JTC_EA_VERSION; }string DataExportCsvSchemaVersion(){ return "8.290-LIGHTWEIGHT-TURN-ADD"; }string DataExportBaseFolder()
{
   return DataExportIsTester() ? "Joon\\Test" : "Joon";
}string DataExportPath(const string file_name)
{
   const string prefix = DataExportIsTester() ? ("TEST_" + DataExportRunId() + "_") : "";
   return DataExportBaseFolder() + "\\" + prefix + file_name;
}string SignalDecisionFileName()
{
   // v8.171: keep the canonical integrated CSV name short and self-identifying.
   // DataExportRunId() begins with YYYYMMDD_HHMMSS; the long chart/data/nonce
   // suffix remains inside the CSV run_id field and is not repeated in the filename.
   const string short_run=StringSubstr(DataExportRunId(),0,15);
   return DataExportPath(StringFormat(
      "JTC_v%s_%s_%s.csv",
      DataExportEaVersion(), TradeLogSafeFileToken(_Symbol), short_run));
}
int main(){
 const string live=SignalDecisionFileName();assert(live=="Joon\\JTC_v8.290_GOLD_20260701_000000.csv");
 tester=true;const string test=SignalDecisionFileName();
 assert(test=="Joon\\Test\\TEST_20260701_000000_12345_D2982846829_4951_JTC_v8.290_GOLD_20260701_000000.csv");
 assert(DataExportCsvSchemaVersion()=="8.290-LIGHTWEIGHT-TURN-ADD");
 std::cout<<live<<"\n"<<test<<"\n";
}
