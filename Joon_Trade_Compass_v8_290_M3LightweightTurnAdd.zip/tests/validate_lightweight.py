from pathlib import Path
import re,subprocess,json,hashlib
P=Path(__file__).resolve().parents[1];E=P/'Joon_Trade_Compass_v8_290_M3LightweightTurnAdd'
export=(E/'DataExportEngine.mqh').read_text(encoding='utf-8-sig')
def fn(name):
 start=export.index(name+'(');start=export.rfind('string ',0,start);a=export.index('{',start);depth=1;i=a+1
 while depth:
  if export[i]=='{':depth+=1
  elif export[i]=='}':depth-=1
  i+=1
 return export[start:i]
macro=re.search(r'^#define JTC_EA_VERSION "([^"]+)"',(E/'CommonTypes.mqh').read_text(encoding='utf-8-sig'),re.M).group(1)
assert macro=='8.290' and '#property version   "8.290"' in (E/'Joon_Trade_Compass_v8_290.mq5').read_text(encoding='utf-8-sig')
header=r'''
#include <string>
#include <cstdio>
#include <cassert>
#include <iostream>
using string=std::string;
bool tester=false;string _Symbol="GOLD";
bool DataExportIsTester(){return tester;}
string DataExportRunId(){return "20260701_000000_12345_D2982846829_4951";}
string TradeLogSafeFileToken(string s){return s;}
string StringSubstr(string s,int start,int n){return s.substr(start,n);}
const char* fmt(const string& v){return v.c_str();}
template<class T>T fmt(T v){return v;}
template<class...A>string StringFormat(const char* f,A...args){char b[1024];std::snprintf(b,sizeof(b),f,fmt(args)...);return b;}
'''
body=r'''
int main(){
 const string live=SignalDecisionFileName();assert(live=="Joon\\JTC_v8.290_GOLD_20260701_000000.csv");
 tester=true;const string test=SignalDecisionFileName();
 assert(test=="Joon\\Test\\TEST_20260701_000000_12345_D2982846829_4951_JTC_v8.290_GOLD_20260701_000000.csv");
 assert(DataExportCsvSchemaVersion()=="8.290-LIGHTWEIGHT-TURN-ADD");
 std::cout<<live<<"\n"<<test<<"\n";
}
'''
src=header+'\n#define JTC_EA_VERSION "'+macro+'"\n'+''.join(fn(n) for n in ['DataExportEaVersion','DataExportCsvSchemaVersion','DataExportBaseFolder','DataExportPath','SignalDecisionFileName'])+body
cpp=P/'tests/csv_name_tests.cpp';cpp.write_text(src)
subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(cpp),'-o',str(P/'tests/csv_name_tests')],check=True)
r=subprocess.run([str(P/'tests/csv_name_tests')],capture_output=True,text=True,check=True);print(r.stdout)
# New mode does not invoke legacy publication/router: it exports canonical rows itself.
runtime=(E/'Runtime.mqh').read_text(encoding='utf-8-sig');tick=runtime[runtime.index('void OnTick()'):]
a=tick.index('if(InpTurnTradeEnabled)');z=tick.index('   if(!InpSystemEnabled)',a);branch=tick[a:z]
assert 'M3_LIGHTWEIGHT_TURN_CANONICAL_AUDIT' in branch and 'if(assist_state_updated' in branch
assert 'ProcessRangeClosedBar' not in branch and 'WatchSignalProcessClosedBar' not in branch and 'M3AutoEngineProcessTick' not in branch
assert 'M3SegmentUpdate(turn_obs,turn_macd,turn_ma,1);' in branch
assert 'g_market_snapshot.closed_bar_time==g_assist_state.bar_time' in branch
assert all('g_market_snapshot.'+n+'>=10' in branch for n in ['loaded_count','common_loaded_count','assist_loaded_count'])
for file in ['TurnCore.mqh','TurnSignalEngine.mqh','TurnDirectionCore.mqh','TurnDirectionEngine.mqh']:
 s=(E/file).read_text();assert not re.search(r'\b(CopyBuffer|CopyRates|MarketDataCopyBuffer|MarketDataCopyRates)\s*\(',s),file
for file in E.iterdir():
 if file.suffix not in ['.mqh','.mq5']:continue
 s=file.read_text(encoding='utf-8-sig')
 for inc in re.findall(r'^\s*#include "([^"]+)"',s,re.M):assert (file.parent/inc).exists(),(file,inc)
 code=re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/','',s);stack=[]
 for c in code:
  if c in '([{':stack.append(c)
  elif c in ')]}':assert stack and stack.pop()=={')':'(',']':'[','}':'{'}[c],file
 assert not stack,file
r={'EA_version':macro,'CSV_schema': '8.290-LIGHTWEIGHT-TURN-ADD','live_and_tester_filename_actual_function_tests':'PASS','csv_columns':632,'closed_bar_canonical_export_retained_in_turn_mode':True,'new_signal_functions_reuse_cached_arrays':True,'whole_MT5_compile':'NOT_RUN','MT5_strategy_test':'NOT_RUN','MT5_performance_benchmark':'NOT_RUN'}
(P/'tests/lightweight_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
