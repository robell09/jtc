from pathlib import Path
import json,numpy as np,pandas as pd
import run_research as R
P=Path(__file__).resolve().parent
checks=[]
a=R.signals('candidate1');orig=R.original
assert np.array_equal(a[0],orig.pre_side.to_numpy(int));assert np.allclose(a[2][a[0]!=0],orig['pivot'].to_numpy()[a[0]!=0]);checks.append('one-bar candidate PRE exactly reproduces current core')
base=json.loads(Path('/workspace/jtc_simulation/simulation_results.json').read_text())
res=json.loads((P/'results.json').read_text());new={x['name']:x for x in res['scenarios']};old={x['name']:x for x in base['scenarios']}
for cap in [0,5]:
 for key in ['closed_net','closed_positions','end_equity_net','bar_close_equity_dd','profit_factor']:
  assert new[f'current_add{cap}'][key]==old[f'combined_add{cap}_sl035'][key],(cap,key)
checks.append('current model reproduces prior no-ADD and ADD5 results exactly')
assert new['current_time10_stress_add0']['closed_net']==old['HYPOTHETICAL_time10_add0_cost2_slip015']['closed_net']
checks.append('stress time-exit control reproduces prior stressed model exactly')
for x in res['scenarios']:
 d=P/'runs'/x['name'];c=pd.read_csv(d/'closed_positions.csv');o=pd.read_csv(d/'orders.csv');e=pd.read_csv(d/'equity.csv');cy=pd.read_csv(d/'cycles.csv')
 assert ((c.side*(c.sl-c.original_sl))>=-1e-8).all(),x['name']
 assert round(c.net.sum(),2)==x['closed_net'];assert len(c)+x['open_positions']==len(o);assert np.all(c.exit_index>=c.entry_index);assert len(e)==R.N;assert abs(e.equity_pnl.iloc[-1]-x['end_equity_net'])<.011
 assert all(cy['adds']<=x['max_add']);assert e.lots.max()<=.03*(x['max_add']+1)+1e-6
checks.append('all scenarios pass accounting, execution time, capacity and final equity invariants')
full_n=R.N;pref=0
for mode,expiry,inv in [('candidate1',0,False),('candidate3',10,True),('swing1',0,False),('swing3',10,True)]:
 full=R.signals(mode,expiry,inv)
 for cut in [1000,5000,10000]:
  R.N=cut;short=R.signals(mode,expiry,inv)
  for k in range(6):assert np.array_equal(full[k][:cut],short[k][:cut]),(mode,cut,k)
  R.N=full_n;pref+=1
checks.append(f'{pref} signal/owner prefix replay tests pass across six output arrays')
a=R.signals('current');R.M.PRE,R.M.DIR,R.M.PIVOT=a[:3];R.M.ATR=R.A
orders=pd.read_csv(P/'runs/current_add0/orders.csv')
for side in [1,-1]:
 row=orders[orders.side==side].iloc[0];sim=R.Research(R.M.Config('budget_rejection'),a,riskcap=.01)
 ok=sim.enter(side,int(row.entry_index),'PRE','INITIAL',R.M.SPREAD[int(row.entry_index)-1])
 assert not ok and sim.blocks['RESEARCH_stop_risk_budget']==1
 assert sim.cash==0 and not sim.positions and not sim.orders and not sim.cycles
checks.append('LONG/SHORT risk-budget rejection leaves cash and positions unchanged; protected SL never widens in all scenarios')
(P/'validation.json').write_text(json.dumps({'status':'passed','scenarios':len(res['scenarios']),'checks':checks},indent=2));print(json.dumps(checks,indent=2))
