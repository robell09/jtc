from pathlib import Path
import pandas as pd,numpy as np,json,math
import broker_model as M
R=Path(__file__).resolve().parent
B=M.B;b=B;N=M.N;A=M.ATR.copy();original=M.S.copy();valid=original.valid.to_numpy(bool)
o,h,l,c=[B['m3_'+z].to_numpy() for z in ['open','high','low','close']];raw=B.assist_raw_macd.to_numpy();wave=B.assist_macd_wave.to_numpy();delta=B.assist_raw_delta.to_numpy();em=B.assist_ema_delta.to_numpy();vol=B.m3_volume.to_numpy();base=B.assist_macd_base.to_numpy();times=M.T

def signals(mode='current',expiry=0,invalidate=False):
 pre=original.pre_side.to_numpy(int).copy() if mode=='current' else np.zeros(N,int);pivot=original['pivot'].to_numpy(float).copy() if mode=='current' else np.zeros(N);events=[]
 if mode!='current':
  candidates={1:None,-1:None};previous={1:None,-1:None};candidate_refs={1:None,-1:None};last={1:-100,-1:-100};used=set()
  for i in range(16,N):
   if not valid[i]:candidates={1:None,-1:None};previous={1:None,-1:None};continue
   # Previously confirmed 1-left/1-right swings are stored only after evaluation; current swing excluded from reference.
   out=[]
   for side in [1,-1]:
    p=candidates[side]
    if p is not None and (i-p>3 or (l[i]<l[p] if side>0 else h[i]>h[p])):
     events.append({'index':i,'pivot_index':p,'side':side,'event':'INVALID_OR_EXPIRED'});candidates[side]=None;p=None
    if p is not None and i>p and (side,p) not in used:
     pri=min(range(p-6,p),key=lambda j:l[j]) if side>0 else max(range(p-6,p),key=lambda j:h[j]);px=l[p] if side>0 else h[p];dist=side*(c[i]-px)/A[i]
     hold=np.all(l[p+1:i+1]>l[p]) if side>0 else np.all(h[p+1:i+1]<h[p]);mom=side*(raw[i]-raw[i-1])/A[i]>.01;wav=side*(wave[i]-wave[i-1])/A[i]>.01;de=side*delta[i]>0 and side*(em[i]-em[i-1])>0
     div=side*(raw[p]-raw[pri])/A[i]>.01
     if mode.startswith('swing'):
      ref=candidate_refs[side]
      div=ref is not None and 3<=p-ref<=40 and side*(px-(l[ref] if side>0 else h[ref]))<0 and side*(raw[p]-raw[ref])/A[i]>.01
     window=1 if mode.endswith('1') else 3
     if i-p<=window and hold and side*(c[i]-c[p])>0 and .15<=dist<=1.25 and mom and wav and de and div and i-last[side]>=3:out.append((side,p,px))
   if len(out)==1:
    side,p,px=out[0];pre[i]=side;pivot[i]=px;last[side]=i;used.add((side,p));events.append({'index':i,'pivot_index':p,'side':side,'event':'CONFIRMED'})
   # Confirmation of generic local swings uses no bars newer than i.
   p=i-1
   if l[p]<l[p-1] and l[p]<l[i]:previous[1]=p
   if h[p]>h[p-1] and h[p]>h[i]:previous[-1]=p
   # New extreme replaces any older candidate. Candidate created here cannot confirm on this same closed bar.
   for side in [1,-1]:
    ext=l[i]<=min(l[i-6:i]) if side>0 else h[i]>=max(h[i-6:i])
    if ext:
     candidates[side]=i;candidate_refs[side]=previous[side];events.append({'index':i,'pivot_index':i,'side':side,'event':'CREATED'})
 direction=np.zeros(N,int);owner=np.zeros(N,int);ownerpivot=np.zeros(N);dead=np.zeros(N,int);s=0;born=-1;px=0.;active=False;last=-1;ph=pl=0.
 for i in range(N):
  if not valid[i]:s=0;active=False;born=-1
  if s and ((expiry and i-born>=expiry) or (invalidate and (l[i]<px if s>0 else h[i]>px))):dead[i]=s;s=0;active=False
  if pre[i]:s=int(pre[i]);born=i;px=pivot[i];active=False;last=-1;ph=pl=0.
  elif s and i>born:
   aligned=(c[i]>c[i-1] and h[i]>h[i-1] and base[i]>base[i-1] and (last<=born or c[i]>ph)) if s>0 else (c[i]<c[i-1] and l[i]<l[i-1] and base[i]<base[i-1] and (last<=born or c[i]<pl))
   if not aligned:active=False
   elif not active:active=True;last=i;ph=h[i];pl=l[i];direction[i]=s
  owner[i]=s;ownerpivot[i]=px if s else 0.
 if mode=='current' and not expiry and not invalidate:assert np.array_equal(direction,original.dir_side.to_numpy(int))
 return pre,direction,pivot,owner,ownerpivot,dead,pd.DataFrame(events)

class Research(M.Simulation):
 def __init__(self,cfg,arrays,distance=1.25,costcap=0.,structural=False,netprofit=False,exit_invalid=False,riskcap=0.):
  super().__init__(cfg);self.a=arrays;self.distance=distance;self.costcap=costcap;self.structural=structural;self.netprofit=netprofit;self.exit_invalid=exit_invalid;self.riskcap=riskcap
 def enter(self,side,index,source,kind,spread):
  if kind=='INITIAL' and self.distance<1.25 and side*(M.OHLC[index,0]+(spread if side>0 else 0)+side*self.c.slip-M.PIVOT[index-1])>self.distance*M.ATR[index-1]:self.blocks['RESEARCH_initial_distance']+=1;return False
  if self.costcap and (spread+2*self.c.slip+.07)/M.ATR[index-1]>self.costcap:self.blocks['RESEARCH_cost_ATR']+=1;return False
  if kind=='ADD' and self.netprofit:
   quote=M.OHLC[index,0]+(spread if side<0 else 0)-side*self.c.slip
   if any(side*(quote-p['fill'])*p['lot']*100+p['swap']-p['fee']<=0 for p in self.positions):self.blocks['RESEARCH_net_layer_profit']+=1;return False
  # Structural stops are applied inside the underlying enter(), before any position/cash mutation.
  self.structural_pivot=self.a[4][index-1] if self.structural else 0.
  return super().enter(side,index,source,kind,spread)
 def accrue(self,prev_index,index):
  super().accrue(prev_index,index)
  if index>0 and self.positions and self.exit_invalid and self.a[5][index-1]==self.side():
   spread=M.SPREAD[index-1]*self.c.spread_scale;side=self.side()
   for p in self.positions[::-1]:self.close(p,M.OHLC[index,0]+(spread if side<0 else 0)-side*self.c.slip,index,'RESEARCH_PIVOT_OR_OWNER_EXIT','OPEN')

def main():
 _,_,_,cal=M.calibrate();result=[];cache={};scenarios=[]
 # Factor-isolated comparisons, then combinations. These are specified research cases, not parameter optimizer results.
 for cap in [0,5]:
  for mode in ['current','candidate1','candidate3','swing1','swing3']:
   scenarios.append(dict(name=f'{mode}_add{cap}',mode=mode,cap=cap))
 for cap in [0,5]:
  scenarios += [dict(name=f'current_owner10_add{cap}',cap=cap,expiry=10,invalidate=True),dict(name=f'current_distance1_add{cap}',cap=cap,distance=1.),dict(name=f'current_cost020_add{cap}',cap=cap,costcap=.2),dict(name=f'current_structureSL_add{cap}',cap=cap,structural=True),dict(name=f'current_owner10_structureSL_add{cap}',cap=cap,expiry=10,invalidate=True,structural=True),dict(name=f'current_owner_exit10_add{cap}',cap=cap,expiry=10,invalidate=True,exit_invalid=True)]
 for mode in ['current','candidate3','swing3']:
  for cap in [0,2,5]:
   scenarios.append(dict(name=f'{mode}_combined_add{cap}',mode=mode,cap=cap,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True))
 for mode in ['current','candidate3','swing3']:
  for cap in [0,5]:scenarios.append(dict(name=f'{mode}_combined_stress_add{cap}',mode=mode,cap=cap,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True,spread_scale=2.,slip=.15))
 for cap in [0,5]:scenarios.append(dict(name=f'current_time10_add{cap}',cap=cap,time_exit_bars=10))
 for cap in [0,5]:scenarios.append(dict(name=f'current_combined_time10_add{cap}',cap=cap,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True,time_exit_bars=10))
 scenarios.append(dict(name='current_stoprisk50_add5',cap=5,riskcap=50.))
 for cap in [0,2,5]:scenarios.append(dict(name=f'current_combined_risk50_add{cap}',cap=cap,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True,riskcap=50.))
 scenarios.append(dict(name='swing3_combined_risk50_add5',mode='swing3',cap=5,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True,riskcap=50.))
 scenarios.append(dict(name='current_combined_risk50_stress_add5',cap=5,expiry=10,invalidate=True,distance=1.,costcap=.2,structural=True,netprofit=True,riskcap=50.,spread_scale=2.,slip=.15))
 for cap in [0,5]:scenarios.append(dict(name=f'current_time10_stress_add{cap}',cap=cap,time_exit_bars=10,spread_scale=2.,slip=.15))
 for case in scenarios:
  mode=case.get('mode','current');key=(mode,case.get('expiry',0),case.get('invalidate',False))
  if key not in cache:
   cache[key]=signals(*key)
   a=cache[key];z=pd.DataFrame({'bar_time':B.m3_bar_time,'pre_side':a[0],'dir_side':a[1],'pivot':a[2],'owner':a[3],'owner_pivot':a[4],'invalidated_side':a[5]});z.to_csv(R/f'signals_{mode}_expiry{key[1]}_invalidate{key[2]}.csv',index=False)
   if len(a[6]):a[6].to_csv(R/f'candidate_events_{mode}.csv',index=False)
  arrays=cache[key];M.PRE,M.DIR,M.PIVOT=arrays[:3];M.ATR=A
  cfg=M.Config(case['name'],max_add=case['cap'],spread_scale=case.get('spread_scale',1.),slip=case.get('slip',0.),time_exit_bars=case.get('time_exit_bars',0))
  sim=Research(cfg,arrays,**{k:case[k] for k in ['distance','costcap','structural','netprofit','exit_invalid','riskcap'] if k in case});stats,closed,cycles,curve,orders=sim.run();stats['research']=case;stats['pre_signals']=int(np.count_nonzero(arrays[0]));stats['direction_signals']=int(np.count_nonzero(arrays[1]));result.append(stats)
  d=R/'runs'/case['name'];d.mkdir(parents=True,exist_ok=True)
  for name,data in [('closed_positions',closed),('cycles',cycles),('equity',curve),('orders',orders)]:data.to_csv(d/f'{name}.csv',index=False)
  (d/'metrics.json').write_text(json.dumps(stats,indent=2))
  print(case['name'],stats['closed_net'],stats['profit_factor'],stats['bar_close_equity_dd'],flush=True)
 pd.DataFrame([{k:v for k,v in s.items() if k not in ['research','blocks']} for s in result]).to_csv(R/'comparison.csv',index=False)
 (R/'results.json').write_text(json.dumps({'calibration':cal,'scenarios':result},indent=2))
if __name__=='__main__':main()
