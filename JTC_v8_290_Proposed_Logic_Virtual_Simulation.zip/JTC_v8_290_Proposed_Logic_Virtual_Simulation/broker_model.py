from pathlib import Path
from dataclasses import dataclass,asdict
from collections import Counter
import pandas as pd,numpy as np,json,math,datetime as dt
R=Path(__file__).resolve().parent
B=pd.read_csv(R/'market_bars.csv');B['bt']=pd.to_datetime(B.m3_bar_time);S=pd.read_csv(R/'signals.csv')
N=len(B);T=(B.bt.astype('int64')//10**9).to_numpy();OHLC=B[['m3_open','m3_high','m3_low','m3_close']].to_numpy(float)
SPREAD=B.spread_points.to_numpy(float)*.01
PRE=S.pre_side.to_numpy(int);DIR=S.dir_side.to_numpy(int);ATR=S.atr.to_numpy(float);PIVOT=S['pivot'].to_numpy(float)
CONTRACT=100.0;ENTRY_FEE_PER_LOT=7.0
# Fitted and validated against original actual fills, not an external broker assumption.
SWAP_LONG_PER_LOT=-69.25;SWAP_SHORT_PER_LOT=17.10

def daily_swap(side,lot,date):
 # Charge previous trading weekday at the server midnight boundary; Wednesday triple.
 prior=date-dt.timedelta(days=1)
 if prior.weekday()>=5:return 0.0
 return round((SWAP_LONG_PER_LOT if side>0 else SWAP_SHORT_PER_LOT)*lot*(3 if prior.weekday()==2 else 1),2)
def swap_between(side,lot,start,end):
 start=pd.Timestamp(start);end=pd.Timestamp(end);date=start.date()+dt.timedelta(days=1);total=0.0
 while date<=end.date():total+=daily_swap(side,lot,date);date+=dt.timedelta(days=1)
 return round(total,2)
def stat(pnls):
 x=np.array(pnls,float);wins=x[x>0];loss=x[x<0];cum=np.r_[0,x.cumsum()]
 return {'closed_positions':len(x),'closed_net':round(float(x.sum()),2),'win_rate_pct':round(float((x>0).mean()*100),2) if len(x) else 0,
 'gross_profit':round(float(wins.sum()),2),'gross_loss':round(float(loss.sum()),2),'profit_factor':round(float(wins.sum()/-loss.sum()),4) if len(loss) else None,
 'realized_position_dd':round(float((np.maximum.accumulate(cum)-cum).max()),2), 'best_position':round(float(x.max()),2) if len(x) else 0,'worst_position':round(float(x.min()),2) if len(x) else 0}
def dd(x):
 a=np.r_[0,np.asarray(x,float)];return round(float((np.maximum.accumulate(a)-a).max()),2)

def calibrate():
 p=pd.read_csv(R/'baseline_deals.csv');e=p[p.event_type.isin(['LIFECYCLE:ENTRY','LIFECYCLE:ADD_ENTRY'])].set_index('position_id');c=p[p.event_type.isin(['LIFECYCLE:CLOSE','LIFECYCLE:STOP_LOSS'])].set_index('position_id');x=c.join(e[['event_price','direction','time_server','realized_profit']],rsuffix='_entry')
 errs=[];model=[];costs=[]
 for idx,row in x.iterrows():
  side=1 if row.direction_entry=='LONG' else -1
  swap=swap_between(side,row.event_volume,row.time_server_entry,row.time_server)
  gross=side*(row.event_price-row.event_price_entry)*row.event_volume*CONTRACT
  pred=round(gross+swap-ENTRY_FEE_PER_LOT*row.event_volume,2);errs.append(pred-row.broker_position_final_pnl);model.append(pred);costs.append(swap)
 # The canonical record for bar i is written at first tick of the following bar.
 bid_open=pd.Series(B.m3_open.to_numpy(),index=B.bt)
 quoted=e.copy();quoted['bucket']=pd.to_datetime(quoted.time_server).dt.floor('3min');quoted['bid_open']=quoted.bucket.map(bid_open)
 quotes=quoted.bid_open+np.where(quoted.direction=='LONG',quoted.spread_points*.01,0)
 qerr=quoted.event_price-quotes
 assert np.max(np.abs(errs))<.011,(np.max(np.abs(errs)),x.iloc[int(np.argmax(np.abs(errs)))].to_dict())
 assert qerr.abs().max()<.00001
 result={'known_closed_positions':len(x),'actual_closed_net':round(x.broker_position_final_pnl.sum(),2),'calibrated_closed_net':round(sum(model),2),'max_per_position_pnl_error':round(max(map(abs,errs)),6),
 'opening_quote_fit_positions':len(e),'max_entry_quote_error':round(qerr.abs().max(),8),'point_and_tick':.01,'contract_multiplier':CONTRACT,'lot':.03,'opening_fee_per_lot':ENTRY_FEE_PER_LOT,'closing_fee_observed':0.0,
 'swap_long_per_lot':SWAP_LONG_PER_LOT,'swap_short_per_lot':SWAP_SHORT_PER_LOT,'triple_swap_previous_weekday':'Wednesday','actual_closed_positions_swap_total':round(sum(costs),2),
 'CSV_original_version':'8.282','actual_SL_pct':.35,'actual_MAX_ADD':5}
 (R/'calibration.json').write_text(json.dumps(result,indent=2));return p,e,c,result

@dataclass
class Config:
 name:str
 max_add:int=5
 pre_add:bool=True
 direction_add:bool=True
 sl_pct:float=.35
 lot:float=.03
 spread_scale:float=1.0
 slip:float=0.0
 protection:str='common_floor'
 max_total_lots:float=0.0
 reverse:bool=True
 long_only:bool=False
 short_only:bool=False
 require_profitable_add:bool=False
 time_exit_bars:int=0

class Simulation:
 def __init__(self,cfg):
  self.c=cfg;self.positions=[];self.closed=[];self.orders=[];self.curve=[];self.cycles={};self.cash=0.;self.cycle_id=0;self.filled_adds=0;self.last_entry_bar=-1;self.protected=0.;self.max_lots=0.;self.blocks=Counter();self.initials=0;self.adds=Counter();self.max_initial_risk=0.;self.intrabar_adverse=[]
 def side(self):return self.positions[0]['side'] if self.positions else 0
 def close(self,pos,exit_price,index,reason,phase):
  timestamp=pd.Timestamp(T[index],unit='s')+(pd.Timedelta(seconds=179) if phase=='WITHIN_BAR' else pd.Timedelta(0))
  gross=pos['side']*(exit_price-pos['fill'])*pos['lot']*CONTRACT
  net=round(gross+pos['swap']-pos['fee'],2)
  self.cash+=gross;self.positions.remove(pos)
  row={**pos,'exit_index':index,'exit_bar':str(B.bt.iloc[index]),'exit_phase':phase,'exit_price':exit_price,'gross':round(gross,2),'net':net,'exit_reason':reason,'hold_hours_est':round((timestamp-pd.Timestamp(pos['entry_time'])).total_seconds()/3600,3)}
  self.closed.append(row);self.cycles[pos['cycle']]['closed_net']+=net
  if not self.positions:self.cycles[pos['cycle']]['flat_index']=index;self.cycles[pos['cycle']]['flat_phase']=phase;self.filled_adds=0;self.protected=0.;self.last_entry_bar=-1
 def stop_check(self,index,spread,intrabar):
  op,hi,lo,cl=OHLC[index]
  for pos in self.positions[:]:
   side=pos['side'];stop=pos['sl']
   hit=(lo<=stop if side>0 else hi+spread>=stop) if intrabar else (op<=stop if side>0 else op+spread>=stop)
   if hit:
    quote=(stop if side>0 else stop) if intrabar else (op if side>0 else op+spread)
    self.close(pos,quote-side*self.c.slip,index,'SL','WITHIN_BAR' if intrabar else 'OPEN_GAP')
 def enter(self,side,index,source,kind,spread):
  c=self.c;op=OHLC[index,0];quote=op+(spread if side>0 else 0.)
  if (c.long_only and side<0) or (c.short_only and side>0):self.blocks['direction_permission']+=1;return False
  if c.max_total_lots>0 and sum(p['lot'] for p in self.positions)+c.lot>c.max_total_lots+1e-9:self.blocks['max_total_lots']+=1;return False
  if kind=='INITIAL':
   distance=side*(quote-PIVOT[index-1])
   if ATR[index-1]<=0 or not(.15*ATR[index-1]<=distance<=1.25*ATR[index-1]):self.blocks['initial_live_ATR_distance']+=1;return False
  else:
   if c.require_profitable_add:
    exitquote=op+(spread if side<0 else 0.)
    if any(side*(exitquote-p['fill'])<=0 for p in self.positions):self.blocks['HYPOTHETICAL_prior_layer_profit_gate']+=1;return False
   if c.max_add<=0 or self.filled_adds>=c.max_add:self.blocks['max_add']+=1;return False
   if self.last_entry_bar>=index:self.blocks['same_entry_bar']+=1;return False
  fill=round(quote+side*c.slip,2)
  distance=quote*c.sl_pct/100
  # Broker stops/freeze zero in source test; minimum one point (.01).
  raw=fill-side*max(distance,.01)
  sl=math.floor((min(raw,op-.01) if side>0 else max(raw,op+spread+.01))/.01+1e-9)*.01 if side>0 else math.ceil(max(raw,op+spread+.01)/.01-1e-9)*.01
  sl=round(sl,2)
  structural_pivot=getattr(self,'structural_pivot',0.)
  if structural_pivot>0:
   buffer=max(.1*ATR[index-1],spread,.01)
   raw_stop=structural_pivot-side*buffer
   sl=round((math.floor(raw_stop/.01+1e-9) if side>0 else math.ceil(raw_stop/.01-1e-9))*.01,2)
   if (side>0 and sl>=op-.01) or (side<0 and sl<=op+spread+.01):self.blocks['RESEARCH_structural_SL_invalid']+=1;return False
  if kind=='INITIAL' and not structural_pivot and abs(fill-sl)>distance+.011:
   self.blocks['initial_SL_feasibility']+=1;return False
  if kind=='ADD' and self.protected>0:
   sl=max(sl,self.protected) if side>0 else min(sl,self.protected)
   if (side>0 and sl>=op-.01) or (side<0 and sl<=op+spread+.01):self.blocks['ADD_protection_floor_rollback']+=1;return False
  if getattr(self,'riskcap',0.)>0:
   projected=max(0.,side*(fill-sl)*c.lot*CONTRACT+ENTRY_FEE_PER_LOT*c.lot)
   for p in self.positions:
    protected_sl=(max(p['sl'],sl) if side>0 else min(p['sl'],sl)) if c.protection=='common_floor' else p['sl']
    projected+=max(0.,side*(p['fill']-protected_sl)*p['lot']*CONTRACT+p['fee']-p['swap'])
   if projected>self.riskcap+1e-9:self.blocks['RESEARCH_stop_risk_budget']+=1;return False
  if kind=='INITIAL':
   self.cycle_id+=1;self.filled_adds=0;self.initials+=1
   self.cycles[self.cycle_id]={'side':side,'start_index':index,'entry_time':str(B.bt.iloc[index]),'closed_net':0.,'adds':0,'flat_index':None}
  else:self.filled_adds+=1;self.adds[source]+=1;self.cycles[self.cycle_id]['adds']+=1
  fee=round(ENTRY_FEE_PER_LOT*c.lot,2)
  pos={'position':len(self.orders)+1,'cycle':self.cycle_id,'entry_index':index,'entry_time':str(B.bt.iloc[index]),'side':side,'lot':c.lot,'fill':fill,'sl':sl,'original_sl':sl,'fee':fee,'swap':0.,'source':source,'kind':kind}
  self.cash-=fee;self.positions.append(pos);self.orders.append({k:pos[k] for k in ['position','cycle','entry_index','entry_time','side','lot','fill','original_sl','source','kind']})
  self.protected=sl
  if c.protection=='common_floor':
   for p in self.positions:p['sl']=max(p['sl'],sl) if side>0 else min(p['sl'],sl)
  self.last_entry_bar=index;self.max_lots=max(self.max_lots,sum(p['lot'] for p in self.positions))
  self.max_initial_risk=max(self.max_initial_risk,sum(abs(p['fill']-p['sl'])*p['lot']*CONTRACT for p in self.positions));return True
 def accrue(self,prev_index,index):
  if prev_index<0:return
  date=B.bt.iloc[prev_index].date()+dt.timedelta(days=1)
  while date<=B.bt.iloc[index].date():
   for p in self.positions:
    sw=daily_swap(p['side'],p['lot'],date);p['swap']=round(p['swap']+sw,2);self.cash+=sw
   date+=dt.timedelta(days=1)
 def run(self):
  for j in range(N):
   spread=SPREAD[j-1]*self.c.spread_scale if j>0 else SPREAD[0]*self.c.spread_scale
   self.accrue(j-1,j);self.stop_check(j,spread,False)
   if self.positions and self.c.time_exit_bars>0 and j-self.cycles[self.cycle_id]['start_index']>=self.c.time_exit_bars:
    side=self.side()
    for p in self.positions[::-1]:self.close(p,OHLC[j,0]+(spread if side<0 else 0.)-side*self.c.slip,j,'HYPOTHETICAL_TIME_EXIT','OPEN')
   # The signal of bar j-1 becomes available at the first tick/open of bar j.
   if j>0:
    pre=PRE[j-1];direction=DIR[j-1];held=self.side()
    if pre:
     if held==pre:
      if self.c.pre_add:self.enter(pre,j,'PRE','ADD',spread)
      else:self.blocks['pre_add_disabled']+=1
     elif held==0:self.enter(pre,j,'PRE','INITIAL',spread)
     else:
      for p in self.positions[::-1]:self.close(p,OHLC[j,0]+(spread if held<0 else 0.)-held*self.c.slip,j,'OPPOSITE_PRE','OPEN')
      # Actual EA waits for callbacks/next tick; model assumes same-open fill with adverse slippage.
      if self.c.reverse:self.enter(pre,j,'PRE','INITIAL',spread)
    elif direction and self.side()==direction:
     if self.c.direction_add:self.enter(direction,j,'DIRECTION','ADD',spread)
     else:self.blocks['direction_add_disabled']+=1
   # All intrabar decisions after opening are broker stops only: no H/L order ambiguity with a TP.
   # Conservative adverse excursion assumes each open layer reaches its stop/adverse bound before close.
   adverse=self.cash
   for p in self.positions:
    worst=max(OHLC[j,2],p['sl']) if p['side']>0 else min(OHLC[j,1]+spread,p['sl'])
    adverse+=p['side']*(worst-p['fill'])*p['lot']*CONTRACT
   self.intrabar_adverse.append(adverse)
   self.stop_check(j,spread,True)
   # Closing spread is observed only now. Its timestamp may be next session after a gap.
   close_spread=SPREAD[j]*self.c.spread_scale
   unreal=sum(p['side']*((OHLC[j,3]+(close_spread if p['side']<0 else 0.))-p['fill'])*p['lot']*CONTRACT for p in self.positions)
   equity=self.cash+unreal
   self.curve.append({'bar_time':str(B.bt.iloc[j]),'close_time':str(B.bt.iloc[j]+pd.Timedelta(minutes=3)),'equity_pnl':round(equity,2),'cash_pnl':round(self.cash,2),'open_positions':len(self.positions),'lots':round(sum(p['lot'] for p in self.positions),3)})
  closed=pd.DataFrame(self.closed);cycles=pd.DataFrame([{'cycle':k,**v} for k,v in self.cycles.items()]);curve=pd.DataFrame(self.curve)
  stats=stat(closed.net.tolist() if len(closed) else [])
  stats.update(asdict(self.c));stats.update({'initials':self.initials,'adds_PRE':self.adds['PRE'],'adds_DIRECTION':self.adds['DIRECTION'],'total_fills':len(self.orders),'closed_cycles':int(cycles.flat_index.notna().sum()) if len(cycles) else 0,
    'open_positions':len(self.positions),'end_equity_net':round(self.cash+unreal,2),'end_unrealized_gross':round(unreal,2),'end_open_entry_fees':round(sum(p['fee'] for p in self.positions),2),
    'bar_close_equity_dd':dd(curve.equity_pnl),'max_lots':round(self.max_lots,3),'max_open_stop_risk':round(self.max_initial_risk,2),'blocks':dict(self.blocks),
    'swap_total':round(sum(p['swap'] for p in self.closed+self.positions),2),'commission_total':round(sum(p['fee'] for p in self.closed+self.positions),2),
    'closed_cycles_win_pct':round(float((cycles.loc[cycles.flat_index.notna(),'closed_net']>0).mean()*100),2) if len(cycles) and cycles.flat_index.notna().any() else 0})
  if len(closed):
   stats['mean_hold_hours']=round(closed.hold_hours_est.mean(),2);stats['SL_closed_positions']=int((closed.exit_reason=='SL').sum());stats['worst_cycle']=round(cycles.closed_net.min(),2);stats['best_cycle']=round(cycles.closed_net.max(),2)
  return stats,closed,cycles,curve,pd.DataFrame(self.orders)

def baseline_curve(p):
 # Actual logged fills/closed net at 3-minute closes; entry commission and per-position swap paid at midnight.
 events=p.copy();events['ts']=pd.to_datetime(events.time_server);events=events.sort_values('ts',kind='stable').to_dict('records');k=0;pos={};cash=0.;curve=[];lastdate=None
 for j in range(N):
  end=B.bt.iloc[j]+pd.Timedelta(minutes=3)
  # Bring logged transactions strictly BEFORE the end bucket, to compare pre-next-bar-order values.
  while k<len(events) and events[k]['ts']<end:
   x=events[k];idx=x['position_id']
   if x['event_type'] in ['LIFECYCLE:ENTRY','LIFECYCLE:ADD_ENTRY']:
    cash+=x['realized_profit'];pos[idx]={'side':1 if x['direction']=='LONG' else -1,'fill':x['event_price'],'lot':x['event_volume'],'time':x['ts']}
   else:
    if idx in pos:
     a=pos.pop(idx);cash+=x['realized_profit'] # Includes actual swap; do not accrue again in realized cash.
   k+=1
  unreal=0.;open_swaps=0.
  for a in pos.values():
   unreal+=a['side']*((OHLC[j,3]+(SPREAD[j] if a['side']<0 else 0.))-a['fill'])*a['lot']*CONTRACT
   open_swaps+=swap_between(a['side'],a['lot'],a['time'],end)
  curve.append({'bar_time':str(B.bt.iloc[j]),'close_time':str(end),'equity_pnl':round(cash+unreal+open_swaps,2),'cash_pnl':round(cash,2),'open_positions':len(pos),'lots':round(sum(a['lot'] for a in pos.values()),3)})
 return pd.DataFrame(curve)

def run_all():
 p,e,c,cal=calibrate();base=baseline_curve(p);base.to_csv(R/'baseline_bar_close_equity.csv',index=False)
 configs=[]
 for cap in [0,1,2,3,5]:
  configs.append(Config(f'combined_add{cap}_sl035',max_add=cap))
 configs += [Config('pre_only_add5_sl035',direction_add=False),Config('direction_only_add5_sl035',pre_add=False)]
 for cap in [0,1,2,3,5]:configs.append(Config(f'combined_add{cap}_sl020',max_add=cap,sl_pct=.2))
 configs += [Config('source_default_lot010_add0_sl020',max_add=0,sl_pct=.2,lot=.1)]
 for spread_scale,slip in [(1,.05),(1,.15),(1.5,0),(2,0),(2,.15)]:
  for cap in [0,2,5]:configs.append(Config(f'cost_add{cap}_spr{spread_scale}_slip{slip}',max_add=cap,spread_scale=spread_scale,slip=slip))
 configs += [Config('HYPOTHETICAL_profit_gate_add5_sl035',require_profitable_add=True),Config('HYPOTHETICAL_profit_gate_add5_sl020',require_profitable_add=True,sl_pct=.2),Config('HYPOTHETICAL_time5_add0_sl035',max_add=0,time_exit_bars=5),Config('HYPOTHETICAL_time5_add5_sl035',time_exit_bars=5),Config('HYPOTHETICAL_time10_add0_sl035',max_add=0,time_exit_bars=10),Config('HYPOTHETICAL_time5_add0_cost2_slip015',max_add=0,time_exit_bars=5,spread_scale=2,slip=.15),Config('HYPOTHETICAL_time10_add0_cost2_slip015',max_add=0,time_exit_bars=10,spread_scale=2,slip=.15)]
 configs += [Config('independent_stops_add5_sl035',protection='independent'),Config('long_only_add5_sl035',long_only=True),Config('short_only_add5_sl035',short_only=True),Config('no_reverse_add5_sl035',reverse=False)]
 (R/'runs').mkdir(exist_ok=True);results=[]
 for cfg in configs:
  sim=Simulation(cfg);stats,closed,cycles,curve,orders=sim.run();results.append(stats)
  d=R/'runs'/cfg.name;d.mkdir(exist_ok=True)
  (d/'metrics.json').write_text(json.dumps(stats,indent=2));closed.to_csv(d/'closed_positions.csv',index=False);cycles.to_csv(d/'cycles.csv',index=False);curve.to_csv(d/'equity.csv',index=False);orders.to_csv(d/'orders.csv',index=False)
 pd.DataFrame([{k:v for k,v in x.items() if k!='blocks'} for x in results]).to_csv(R/'scenario_comparison.csv',index=False)
 (R/'simulation_results.json').write_text(json.dumps({'calibration':cal,'baseline_bar_close_dd':dd(base.equity_pnl),'baseline_estimated_last_equity_pnl':float(base.equity_pnl.iloc[-1]),'baseline_original_closed_net':cal['actual_closed_net'],'scenarios':results},indent=2))
 print(pd.DataFrame(results)[['name','initials','adds_PRE','adds_DIRECTION','closed_net','end_equity_net','profit_factor','realized_position_dd','bar_close_equity_dd','max_lots']].to_string(index=False))
if __name__=='__main__':run_all()
