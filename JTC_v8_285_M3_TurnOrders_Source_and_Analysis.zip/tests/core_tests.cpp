#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <limits>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cassert>
using datetime=long long;
struct MqlRates {datetime time;double open,high,low,close;};
const double EMPTY_VALUE=std::numeric_limits<double>::max();
template<class T> void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T> int ArraySize(const std::vector<T> &v){return int(v.size());}
template<class T> T MathMax(T a,T b){return std::max(a,b);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
double MathAbs(double v){return std::abs(v);}
#ifndef JTC_TURN_CORE_MQH
#define JTC_TURN_CORE_MQH
// Pure causal core: shift >=1, pivot=shift+1; no forming/future bar reads.
struct JTC_TURN_FRAME
{
   bool valid;
   datetime bar_time;
   datetime pivot_time;
   double close_price;
   double high_price;
   double low_price;
   double pivot_close;
   double pivot_high;
   double pivot_low;
   double prior_low;
   double prior_high;
   double atr14;
   double raw_step_r;
   double wave_step_r;
   double raw_delta_pressure;
   double delta_step_norm;
   double long_divergence_r;
   double short_divergence_r;
};
struct JTC_TURN_RESULT
{
   int side;
   int long_score;
   int short_score;
   bool low_candidate;
   bool high_candidate;
   bool long_divergence;
   bool short_divergence;
   double distance_r;
   double pivot_price;
};
bool JTC_TurnFinite(const double v)
{
   return v!=EMPTY_VALUE && MathIsValidNumber(v);
}
void JTC_TurnBuildFrame(const std::vector<MqlRates> &r,const std::vector<double> &raw,
                       const std::vector<double> &wave,const std::vector<double> &delta,
                       const std::vector<double> &ema,const std::vector<double> &volume,
                       const int shift,const int left_bars,JTC_TURN_FRAME &f)
{
   ZeroMemory(f);
   if(shift<1 || left_bars<2 || left_bars>12) return;
   const int last=shift+MathMax(14,left_bars+1);
   if(ArraySize(r)<=last || ArraySize(raw)<=last || ArraySize(wave)<=shift+1 ||
      ArraySize(delta)<=shift || ArraySize(ema)<=shift+1 || ArraySize(volume)<=shift+1) return;
   for(int j=shift;j<=last;j++)
   {
      if(r[j].time<=0 || !JTC_TurnFinite(r[j].high) || !JTC_TurnFinite(r[j].low) ||
         !JTC_TurnFinite(r[j].close) || r[j].high<r[j].low ||
         r[j].close<r[j].low || r[j].close>r[j].high) return;
      if(j<last && r[j].time-r[j+1].time!=180) return;
   }
   for(int j=shift;j<=shift+1;j++)
      if(!JTC_TurnFinite(raw[j]) || !JTC_TurnFinite(wave[j]) ||
         !JTC_TurnFinite(ema[j]) || !JTC_TurnFinite(volume[j]) || volume[j]<=0.0) return;
   if(!JTC_TurnFinite(delta[shift])) return;
   int prior_low_idx=shift+2,prior_high_idx=shift+2;
   for(int j=shift+3;j<=shift+left_bars+1;j++)
   {
      // Strict comparisons keep the most recent extreme on equal prices.
      if(r[j].low<r[prior_low_idx].low) prior_low_idx=j;
      if(r[j].high>r[prior_high_idx].high) prior_high_idx=j;
   }
   if(!JTC_TurnFinite(raw[prior_low_idx]) || !JTC_TurnFinite(raw[prior_high_idx])) return;
   double tr=0.0;
   for(int j=shift;j<shift+14;j++)
      tr+=MathMax(r[j].high-r[j].low,
          MathMax(MathAbs(r[j].high-r[j+1].close),MathAbs(r[j].low-r[j+1].close)));
   const double atr=tr/14.0;
   if(!JTC_TurnFinite(atr) || atr<=0.0) return;
   const int p=shift+1;
   f.bar_time=r[shift].time; f.pivot_time=r[p].time;
   f.close_price=r[shift].close; f.high_price=r[shift].high; f.low_price=r[shift].low;
   f.pivot_close=r[p].close; f.pivot_high=r[p].high; f.pivot_low=r[p].low;
   f.prior_low=r[prior_low_idx].low; f.prior_high=r[prior_high_idx].high;
   f.atr14=atr;
   f.raw_step_r=(raw[shift]-raw[p])/atr;
   f.wave_step_r=(wave[shift]-wave[p])/atr;
   f.raw_delta_pressure=delta[shift]/volume[shift];
   f.delta_step_norm=(ema[shift]-ema[p])/((volume[shift]+volume[p])*0.5);
   f.long_divergence_r=(raw[p]-raw[prior_low_idx])/atr;
   f.short_divergence_r=(raw[prior_high_idx]-raw[p])/atr;
   f.valid=true;
}
void JTC_TurnDecide(const JTC_TURN_FRAME &f,const bool require_divergence,
                   const double min_rebound,const double max_distance,
                   const double momentum_deadzone,JTC_TURN_RESULT &q)
{
   ZeroMemory(q);
   if(!f.valid || !JTC_TurnFinite(f.atr14) || f.atr14<=0.0 || min_rebound<0.0 || max_distance<min_rebound || momentum_deadzone<0.0) return;
   const double ld=(f.close_price-f.pivot_low)/f.atr14;
   const double sd=(f.pivot_high-f.close_price)/f.atr14;
   q.low_candidate=(f.pivot_low<=f.prior_low && f.low_price>f.pivot_low &&
      f.close_price>f.pivot_close && ld>=min_rebound && ld<=max_distance);
   q.high_candidate=(f.pivot_high>=f.prior_high && f.high_price<f.pivot_high &&
      f.close_price<f.pivot_close && sd>=min_rebound && sd<=max_distance);
   q.long_divergence=(f.long_divergence_r>momentum_deadzone);
   q.short_divergence=(f.short_divergence_r>momentum_deadzone);
   const bool dl=(f.raw_delta_pressure>0.0 && f.delta_step_norm>0.0);
   const bool ds=(f.raw_delta_pressure<0.0 && f.delta_step_norm<0.0);
   q.long_score=(f.raw_step_r>momentum_deadzone ? 1 : 0)+
      (f.wave_step_r>momentum_deadzone ? 1 : 0)+(dl ? 1 : 0);
   q.short_score=(f.raw_step_r<-momentum_deadzone ? 1 : 0)+
      (f.wave_step_r<-momentum_deadzone ? 1 : 0)+(ds ? 1 : 0);
   const bool good_long=q.low_candidate && q.long_score==3 &&
      (!require_divergence || q.long_divergence);
   const bool good_short=q.high_candidate && q.short_score==3 &&
      (!require_divergence || q.short_divergence);
   if(good_long==good_short) return; // both/none never invent a direction
   q.side=(good_long ? 1 : -1);
   q.distance_r=(good_long ? ld : sd);
   q.pivot_price=(good_long ? f.pivot_low : f.pivot_high);
}
bool JTC_TurnEmit(const datetime bar,const int side,const int cooldown_bars,
                  datetime &last_long,datetime &last_short)
{
   if(bar<=0 || (side!=1 && side!=-1) || cooldown_bars<1) return false;
   const datetime prior=(side>0 ? last_long : last_short);
   if(prior>0 && bar-prior<(long)cooldown_bars*180) return false;
   if(side>0) last_long=bar; else last_short=bar;
   return true;
}
#endif

int main(int argc,char **argv){
 if(argc!=3)return 2;
 std::ifstream in(argv[1]);std::vector<MqlRates> chronological;
 std::vector<double> cr,cw,cd,ce,cv;
 MqlRates a;double rm,wm,dm,em,vm;
 while(in>>a.time>>a.open>>a.high>>a.low>>a.close>>rm>>wm>>dm>>em>>vm){
  chronological.push_back(a);cr.push_back(rm);cw.push_back(wm);cd.push_back(dm);ce.push_back(em);cv.push_back(vm);
 }
 int n=chronological.size();std::vector<MqlRates> r(n+1);
 std::vector<double> raw(n+1),wave(n+1),delta(n+1),ema(n+1),volume(n+1);
 for(int i=0;i<n;i++){int k=n-i;r[k]=chronological[i];raw[k]=cr[i];wave[k]=cw[i];delta[k]=cd[i];ema[k]=ce[i];volume[k]=cv[i];}
 std::ofstream out(argv[2]);out<<"index,side,pivot_price,distance_r\n";out<<std::setprecision(15);
 datetime ll=0,ls=0;int emitted=0;
 for(int i=0;i<n;i++){
  int shift=n-i;JTC_TURN_FRAME f;JTC_TURN_RESULT q;
  JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,shift,6,f);
  JTC_TurnDecide(f,true,.15,1.25,.01,q);
  if(i==5000){ // Mutating ALL later/forming bars must not alter this decision.
   auto r2=r;auto raw2=raw;auto wave2=wave;auto d2=delta;auto e2=ema;auto v2=volume;
   for(int k=0;k<shift;k++){r2[k].high=999999;r2[k].low=-999999;r2[k].close=888888;raw2[k]=999;wave2[k]=-999;d2[k]=123;e2[k]=-321;v2[k]=99999;}
   JTC_TURN_FRAME f2;JTC_TURN_RESULT q2;
   JTC_TurnBuildFrame(r2,raw2,wave2,d2,e2,v2,shift,6,f2);JTC_TurnDecide(f2,true,.15,1.25,.01,q2);
   assert(f.valid==f2.valid && f.raw_step_r==f2.raw_step_r && f.long_divergence_r==f2.long_divergence_r);
   assert(q.side==q2.side && q.pivot_price==q2.pivot_price);
  }
  if(q.side && JTC_TurnEmit(f.bar_time,q.side,3,ll,ls)){out<<i<<","<<q.side<<","<<q.pivot_price<<","<<q.distance_r<<"\n";emitted++;}
 }
 JTC_TURN_FRAME f;JTC_TURN_RESULT q;
 JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,0,6,f);assert(!f.valid);
 JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,1,1,f);assert(!f.valid);
 auto bad=raw;bad[1]=EMPTY_VALUE;JTC_TurnBuildFrame(r,bad,wave,delta,ema,volume,1,6,f);assert(!f.valid);
 auto gap=r;gap[2].time-=1;JTC_TurnBuildFrame(gap,raw,wave,delta,ema,volume,1,6,f);assert(!f.valid);
 auto zero=volume;zero[1]=0;JTC_TurnBuildFrame(r,raw,wave,delta,ema,zero,1,6,f);assert(!f.valid);
 ZeroMemory(f);f.valid=true;JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==0);
 datetime L=0,S=0;assert(JTC_TurnEmit(1000,1,3,L,S));assert(!JTC_TurnEmit(1000,1,3,L,S));assert(!JTC_TurnEmit(1539,1,3,L,S));assert(JTC_TurnEmit(1540,1,3,L,S));assert(JTC_TurnEmit(1000,-1,3,L,S));
 // Synthetic causal low/high with all confirmations and divergence.
 ZeroMemory(f);f.valid=true;f.atr14=1;f.close_price=10.8;f.low_price=10.2;f.high_price=11;
 f.pivot_low=10;f.pivot_high=12;f.pivot_close=10.5;f.prior_low=10.1;f.prior_high=13;
 f.raw_step_r=.02;f.wave_step_r=.02;f.raw_delta_pressure=.2;f.delta_step_norm=.02;f.long_divergence_r=.03;
 JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==1 && q.pivot_price==10);
 f.long_divergence_r=0;JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==0);
 JTC_TurnDecide(f,false,.15,1.25,.01,q);assert(q.side==1);
 f.close_price=13.2;f.high_price=13.8;f.low_price=13;f.pivot_high=14;f.pivot_low=12;
 f.pivot_close=13.5;f.prior_high=13.9;f.prior_low=11;f.raw_step_r=-.02;f.wave_step_r=-.02;
 f.raw_delta_pressure=-.2;f.delta_step_norm=-.02;f.short_divergence_r=.03;
 JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==-1 && q.pivot_price==14);
 std::cout<<n<<" bars, "<<emitted<<" emitted; causal/boundary checks passed\n";
}
