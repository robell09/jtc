from pathlib import Path
import re,subprocess,pandas as pd,numpy as np,json,hashlib,difflib
R=Path(__file__).resolve().parents[1];pkg=R/'package' if (R/'package').exists() else R
import sys
sys.path.insert(0,str(R/'analysis'))
from load_bars import load_bars
b=load_bars()
cols=['m3_open','m3_high','m3_low','m3_close','assist_raw_macd','assist_macd_wave','assist_raw_delta','assist_ema_delta','m3_volume']
x=b[cols].apply(pd.to_numeric).copy();x.insert(0,'epoch',b.bt.astype('int64')//10**9);x.to_csv(R/'tests/input.tsv',sep=' ',index=False,header=False,float_format='%.12g')
core=(pkg/'MQL5/Experts/Joon_Trade_Compass_v8_285_TurnOrders/TurnCore.mqh').read_text();core=re.sub(r'const (MqlRates|double) &(\w+)\[\]',r'const std::vector<\1> &\2',core)
header='''#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <limits>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cassert>
using datetime=long long;
struct MqlRates {datetime time;double open,high,low,close;};
const double EMPTY_VALUE=std::numeric_limits<double>::max();
template<class T> void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T> int ArraySize(const std::vector<T> &v){return int(v.size());}
template<class T> T MathMax(T a,T b){return std::max(a,b);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
double MathAbs(double v){return std::abs(v);}
'''
body=r'''
int main(int argc,char **argv){
 if(argc!=3)return 2;
 std::ifstream in(argv[1]);std::vector<MqlRates> chronological;
 std::vector<double> cr,cw,cd,ce,cv;
 MqlRates a;double rm,wm,dm,em,vm;
 while(in>>a.time>>a.open>>a.high>>a.low>>a.close>>rm>>wm>>dm>>em>>vm){
  chronological.push_back(a);cr.push_back(rm);cw.push_back(wm);cd.push_back(dm);ce.push_back(em);cv.push_back(vm);
 }
 int n=chronological.size();std::vector<MqlRates> r(n+1);
 std::vector<double> raw(n+1),wave(n+1),delta(n+1),ema(n+1),volume(n+1);
 for(int i=0;i<n;i++){int k=n-i;r[k]=chronological[i];raw[k]=cr[i];wave[k]=cw[i];delta[k]=cd[i];ema[k]=ce[i];volume[k]=cv[i];}
 std::ofstream out(argv[2]);out<<"index,side,pivot_price,distance_r\n";out<<std::setprecision(15);
 datetime ll=0,ls=0;int emitted=0;
 for(int i=0;i<n;i++){
  int shift=n-i;JTC_TURN_FRAME f;JTC_TURN_RESULT q;
  JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,shift,6,f);
  JTC_TurnDecide(f,true,.15,1.25,.01,q);
  if(i==5000){ // Mutating ALL later/forming bars must not alter this decision.
   auto r2=r;auto raw2=raw;auto wave2=wave;auto d2=delta;auto e2=ema;auto v2=volume;
   for(int k=0;k<shift;k++){r2[k].high=999999;r2[k].low=-999999;r2[k].close=888888;raw2[k]=999;wave2[k]=-999;d2[k]=123;e2[k]=-321;v2[k]=99999;}
   JTC_TURN_FRAME f2;JTC_TURN_RESULT q2;
   JTC_TurnBuildFrame(r2,raw2,wave2,d2,e2,v2,shift,6,f2);JTC_TurnDecide(f2,true,.15,1.25,.01,q2);
   assert(f.valid==f2.valid && f.raw_step_r==f2.raw_step_r && f.long_divergence_r==f2.long_divergence_r);
   assert(q.side==q2.side && q.pivot_price==q2.pivot_price);
  }
  if(q.side && JTC_TurnEmit(f.bar_time,q.side,3,ll,ls)){out<<i<<","<<q.side<<","<<q.pivot_price<<","<<q.distance_r<<"\n";emitted++;}
 }
 JTC_TURN_FRAME f;JTC_TURN_RESULT q;
 JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,0,6,f);assert(!f.valid);
 JTC_TurnBuildFrame(r,raw,wave,delta,ema,volume,1,1,f);assert(!f.valid);
 auto bad=raw;bad[1]=EMPTY_VALUE;JTC_TurnBuildFrame(r,bad,wave,delta,ema,volume,1,6,f);assert(!f.valid);
 auto gap=r;gap[2].time-=1;JTC_TurnBuildFrame(gap,raw,wave,delta,ema,volume,1,6,f);assert(!f.valid);
 auto zero=volume;zero[1]=0;JTC_TurnBuildFrame(r,raw,wave,delta,ema,zero,1,6,f);assert(!f.valid);
 ZeroMemory(f);f.valid=true;JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==0);
 datetime L=0,S=0;assert(JTC_TurnEmit(1000,1,3,L,S));assert(!JTC_TurnEmit(1000,1,3,L,S));assert(!JTC_TurnEmit(1539,1,3,L,S));assert(JTC_TurnEmit(1540,1,3,L,S));assert(JTC_TurnEmit(1000,-1,3,L,S));
 // Synthetic causal low/high with all confirmations and divergence.
 ZeroMemory(f);f.valid=true;f.atr14=1;f.close_price=10.8;f.low_price=10.2;f.high_price=11;
 f.pivot_low=10;f.pivot_high=12;f.pivot_close=10.5;f.prior_low=10.1;f.prior_high=13;
 f.raw_step_r=.02;f.wave_step_r=.02;f.raw_delta_pressure=.2;f.delta_step_norm=.02;f.long_divergence_r=.03;
 JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==1 && q.pivot_price==10);
 f.long_divergence_r=0;JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==0);
 JTC_TurnDecide(f,false,.15,1.25,.01,q);assert(q.side==1);
 f.close_price=13.2;f.high_price=13.8;f.low_price=13;f.pivot_high=14;f.pivot_low=12;
 f.pivot_close=13.5;f.prior_high=13.9;f.prior_low=11;f.raw_step_r=-.02;f.wave_step_r=-.02;
 f.raw_delta_pressure=-.2;f.delta_step_norm=-.02;f.short_divergence_r=.03;
 JTC_TurnDecide(f,true,.15,1.25,.01,q);assert(q.side==-1 && q.pivot_price==14);
 std::cout<<n<<" bars, "<<emitted<<" emitted; causal/boundary checks passed\n";
}
'''
(R/'tests/core_tests.cpp').write_text(header+core+body)
subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(R/'tests/core_tests.cpp'),'-o',str(R/'tests/core_tests')],check=True)
r=subprocess.run([str(R/'tests/core_tests'),str(R/'tests/input.tsv'),str(R/'tests/cpp_signals.csv')],text=True,capture_output=True,check=True);print(r.stdout)
actual=pd.read_csv(R/'tests/cpp_signals.csv');expected=pd.read_csv(R/'analysis/turn_divergence.csv')
assert actual['index'].tolist()==expected['index'].tolist(),(len(actual),len(expected),set(actual['index'])^set(expected['index']))
assert actual['side'].tolist()==expected['side'].tolist()
assert np.allclose(actual.distance_r,expected.distance_atr,rtol=1e-8,atol=1e-8)
assert actual['index'].is_unique
# All local includes and version/schema counts are consistent.
for p in pkg.rglob('*'):
 if p.suffix in ['.mq5','.mqh']:
  for inc in re.findall(r'^\s*#include "([^"]+)"',p.read_text(),re.M):assert (p.parent/inc).is_file(),(p,inc)
ea=pkg/'MQL5/Experts/Joon_Trade_Compass_v8_285_TurnOrders';orig=Path('/workspace/jtc_test_build/Joon_Trade_Compass_v8_283_ReviewTest');exp=(ea/'DataExportEngine.mqh').read_text()
headers=re.findall(r'DataExportCsvAdd\(header, "(turn_pre_[^"]+)"\)',exp);assert len(headers)==16 and len(set(headers))==16
start=exp.index('DataExportCsvAdd(row, g_assist_state.turn_pre_enabled');end=exp.index('DataExportCsvAdd(row,',exp.index('DoubleToString(g_assist_state.turn_pre_atr14,8)',start)+len('DoubleToString(g_assist_state.turn_pre_atr14,8)'))
assert len(re.findall(r'DataExportCsvAdd\(row,',exp[start:end]))==16
assert 'return 628;' in exp and '8.285-TURNPRE-ORDERS' in exp
unchanged=['EntryEngine.mqh','ExitEngine.mqh','RiskEngine.mqh','TradeExecutionEngine.mqh','SignalEngine.mqh','M3SegmentEngine.mqh']
baseline=json.loads((R/'tests/baseline_hashes_8_283.json').read_text())
for name in unchanged:assert hashlib.sha256((ea/name).read_bytes()).hexdigest()==baseline[name],name
assert (ea/'TurnCore.mqh').read_bytes()==(pkg/'MQL5/Indicators/JTC_TurnPre/TurnCore.mqh').read_bytes()
patch=[]
for p in ea.glob('*.mqh'):
 if (orig/p.name).exists():patch.extend(difflib.unified_diff((orig/p.name).read_text().splitlines(True),p.read_text().splitlines(True),fromfile='v8.283/'+p.name,tofile='v8.285/'+p.name))
(R/'tests/changes_from_8_283.patch').write_text(''.join(patch))
result={'csv_bars_checked':len(b),'emitted_signal_count':len(actual),'python_vs_actual_core_full_sequence_match':True,'forming_and_future_bars_mutation_check':True,'shift0_gap_missing_volume_invalid_parameters_and_cooldown_checks':'passed','synthetic_long_short_and_divergence_toggle':'passed','csv_added_fields':headers,'expected_csv_columns':628,'trading_modules_unchanged_vs_8_283':unchanged,'whole_MT5_compile':'NOT_RUN','MT5_backtest':'NOT_RUN'}
(R/'tests/validation.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
