import pandas as pd,numpy as np,json,pathlib
R=pathlib.Path(__file__).resolve().parent;b=__import__('load_bars').load_bars()
x=lambda k:pd.to_numeric(b[k],errors='coerce')
close=x('m3_close');op=x('m3_open');h=x('m3_high');l=x('m3_low');vol=x('m3_volume')
pressure=(.7*(2*close-h-l)/(h-l)+.3*(close-op)/(h-l)).fillna(0).clip(-1,1)
raw=vol*pressure;ema=raw.ewm(span=14,adjust=False).mean();macd=close.ewm(span=12,adjust=False).mean()-close.ewm(span=26,adjust=False).mean()
result={}
for name,calc,actual in [('delta_raw',raw,x('assist_raw_delta')),('delta_ema',ema,x('assist_ema_delta')),('raw_price_macd',macd,x('assist_raw_macd'))]:
 d=(calc-actual).abs().iloc[500:];result[name]={'compared_after_500_bar_seed_warmup':len(d),'median_abs_error':float(d.median()),'max_abs_error':float(d.max()),'fraction_error_lt_1e_6':float((d<1e-6).mean())}
(R/'indicator_parity.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
