import os
from pathlib import Path
cache=Path(__file__).resolve().parents[1]/'cache'
os.environ['MPLCONFIGDIR']=str(cache/'mpl');os.environ['XDG_CACHE_HOME']=str(cache)
from pathlib import Path
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg');import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
R=Path(__file__).resolve().parent;b=__import__('load_bars').load_bars();s=pd.read_csv(R/'turn_divergence.csv');v=s[s.return_5.notna()]
# Deterministic selection: first evaluable LONG and SHORT; no outcome selection.
picks=[v[v.side==side].iloc[0] for side in [1,-1]]
fig,axes=plt.subplots(3,2,figsize=(15,9),gridspec_kw={'height_ratios':[3,1,1]},layout='constrained')
for column,sig in enumerate(picks):
 i=int(sig['index']);start=max(0,i-24);stop=min(len(b),i+17);z=b.iloc[start:stop];xs=np.arange(len(z));ax=axes[0,column]
 for j,row in enumerate(z.itertuples(index=False)):
  o,h,l,c=[float(getattr(row,'m3_'+k)) for k in ['open','high','low','close']];color='#19856e' if c>=o else '#b94f58';ax.plot([j,j],[l,h],color=color,lw=.8);ax.add_patch(Rectangle((j-.32,min(o,c)),.64,max(abs(c-o),.02),facecolor=color,edgecolor=color))
 p=i-1-start;t=i-start;side=int(sig.side);pivot=float(b.iloc[i-1]['m3_low' if side>0 else 'm3_high']);current=float(b.iloc[i]['m3_low' if side>0 else 'm3_high']);off=float(sig.atr)*.12
 ax.scatter([p],[pivot],color='grey',s=35,zorder=5);ax.scatter([t],[current-side*off],marker='^' if side>0 else 'v',color='#116aaf',s=100,zorder=5)
 ax.axvline(t+.5,color='#116aaf',ls=':',lw=1);ax.annotate('Signal known after this candle closes',xy=(t+.5,float(b.iloc[i].m3_close)),xytext=(.03,.96),textcoords='axes fraction',arrowprops={'arrowstyle':'->','color':'#116aaf'},fontsize=9,va='top')
 ax.set_title(f"First evaluable {'LOW / LONG' if side>0 else 'HIGH / SHORT'}: {sig.bar_time}\n5-bar direction return {sig.return_5:+.3f} ATR (no trading costs)");ax.set_ylabel('GOLD price')
 for row,k in [(1,'assist_raw_macd'),(1,'assist_macd_wave')]:axes[row,column].plot(xs,pd.to_numeric(z[k]),label=k.replace('assist_',''))
 axes[1,column].legend(loc='best',fontsize=8);axes[1,column].axhline(0,color='grey',lw=.5)
 axes[2,column].bar(xs,pd.to_numeric(z.assist_raw_delta),color='silver',label='Raw pressure x volume');axes[2,column].plot(xs,pd.to_numeric(z.assist_ema_delta),color='#654a91',label='EMA delta');axes[2,column].legend(loc='best',fontsize=8)
 ticks=list(range(0,len(z),7));labels=[z.iloc[j].m3_bar_time[11:16] for j in ticks]
 for row in range(3):axes[row,column].set_xticks(ticks,labels);axes[row,column].axvline(t+.5,color='#116aaf',ls=':',lw=.7)
 axes[2,column].set_xlabel('M3 bar start (server time); grey dot is a later-confirmed pivot annotation')
fig.suptitle('JTC v8.284 causal turn pre-signal | same core used in EA and standalone indicator',fontsize=14)
fig.savefig(R/'turn_chart_examples.png',dpi=150);fig.savefig(R/'turn_chart_examples.svg')
print(R/'turn_chart_examples.png')
