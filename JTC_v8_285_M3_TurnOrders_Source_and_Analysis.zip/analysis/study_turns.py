import pandas as pd,numpy as np,json,pathlib
R=pathlib.Path(__file__).resolve().parent;b=__import__('load_bars').load_bars()
num=lambda k:pd.to_numeric(b[k],errors='coerce')
o,h,l,c=[num('m3_'+k) for k in ['open','high','low','close']];raw=num('assist_raw_macd');wave=num('assist_macd_wave');d=num('assist_raw_delta');ema=num('assist_ema_delta');vol=num('m3_volume')
tr=pd.concat([h-l,(h-c.shift()).abs(),(l-c.shift()).abs()],axis=1).max(axis=1);atr=tr.rolling(14).mean()
priorlo=l.shift(2).rolling(6).min();priorhi=h.shift(2).rolling(6).max()
cont=b.bt.diff().eq(pd.Timedelta(minutes=3)).rolling(14).sum().eq(14)
rawstep=(raw-raw.shift())/atr;rawaccel=(raw-2*raw.shift()+raw.shift(2))/atr
wavestep=(wave-wave.shift())/atr;waveaccel=(wave-2*wave.shift()+wave.shift(2))/atr
pdelta=d/vol;dstep=(ema-ema.shift())/((vol+vol.shift())*.5)
frames=pd.DataFrame({'index':b.index,'bar_time':b.m3_bar_time,'pivot_time':b.m3_bar_time.shift(),'time':b.bt,'valid':cont&atr.gt(0)&vol.gt(0)&vol.shift().gt(0),'close':c,'high':h,'low':l,'pivot_close':c.shift(),'pivot_high':h.shift(),'pivot_low':l.shift(),'prior_low':priorlo,'prior_high':priorhi,'atr':atr,'raw_step_r':rawstep,'raw_accel_r':rawaccel,'wave_step_r':wavestep,'wave_accel_r':waveaccel,'raw_delta_pressure':pdelta,'delta_step_norm':dstep})
def evaluate(fr,minscore=3,cooldown=3):
 results=[];last={1:None,-1:None}
 for row in fr.itertuples(index=False):
  if not row.valid:continue
  sides=[]
  for side in [1,-1]:
   price=(row.pivot_low<=row.prior_low and row.low>row.pivot_low and row.close>row.pivot_close) if side>0 else (row.pivot_high>=row.prior_high and row.high<row.pivot_high and row.close<row.pivot_close)
   dist=(row.close-row.pivot_low)/row.atr if side>0 else (row.pivot_high-row.close)/row.atr
   price=price and .15<=dist<=1.25
   rm=side*row.raw_step_r>.01 or side*row.raw_accel_r>.01
   wm=side*row.wave_step_r>.01 or side*row.wave_accel_r>.01
   dm=side*row.raw_delta_pressure>0 and side*row.delta_step_norm>0
   score=int(rm)+int(wm)+int(dm)
   if price and dm and score>=minscore:sides.append((side,score,dist))
  if len(sides)!=1:continue
  side,score,dist=sides[0]
  if last[side] is not None and (row.time-last[side]).total_seconds()<cooldown*180:continue
  last[side]=row.time
  results.append({'index':row.index,'bar_time':row.bar_time,'available_time':str(row.time+pd.Timedelta(minutes=3)),'pivot_time':row.pivot_time,'side':side,'score':score,'distance_atr':dist,'atr':row.atr})
 return pd.DataFrame(results)
def outcome(sig):
 rows=[]
 for x in sig.itertuples(index=False):
  i=x.index;row=x._asdict();row['month']='July' if b.bt.iloc[i]<pd.Timestamp('2026-08-01') else 'August'
  for horizon in [3,5,8]:
   valid=i+horizon<len(b) and (b.bt.iloc[i:i+horizon+1].diff().dropna()==pd.Timedelta(minutes=3)).all()
   row['return_'+str(horizon)]=x.side*(c.iloc[i+horizon]-c.iloc[i])/x.atr if valid else np.nan
   if valid and horizon==5:
    up=(h.iloc[i+1:i+6]-c.iloc[i])/x.atr if x.side>0 else (c.iloc[i]-l.iloc[i+1:i+6])/x.atr
    dn=(c.iloc[i]-l.iloc[i+1:i+6])/x.atr if x.side>0 else (h.iloc[i+1:i+6]-c.iloc[i])/x.atr
    row['mfe5']=up.max();row['mae5']=dn.max();row['barrier5']='timeout'
    for a,z in zip(up,dn):
     if a>=1 and z>=1:row['barrier5']='ambiguous';break
     if a>=1:row['barrier5']='target';break
     if z>=1:row['barrier5']='stop';break
  # Retrospective swing quality only, never input to signal calculation.
  if i+5<len(b) and (b.bt.iloc[i-1:i+6].diff().dropna()==pd.Timedelta(minutes=3)).all():
   row['pivot_survives5']=bool((l.iloc[i:i+6]>=l.iloc[i-1]).all()) if x.side>0 else bool((h.iloc[i:i+6]<=h.iloc[i-1]).all())
  rows.append(row)
 return pd.DataFrame(rows)
def stat(x):
 r={'signals':len(x)}
 for horizon in [3,5,8]:
  v=x['return_'+str(horizon)].dropna();r['h'+str(horizon)]={'valid':len(v),'positive_fraction':float((v>0).mean()),'mean_atr':float(v.mean()),'median_atr':float(v.median())}
 r['barrier5']=x.barrier5.value_counts().to_dict();return r
if __name__ == '__main__':
 res={}
 for score in [3,2]:
  q=outcome(evaluate(frames,minscore=score));q.to_csv(R/f'turn_signals_score{score}.csv',index=False)
  res[str(score)]={'all':stat(q),'by_month':{k:stat(x) for k,x in q.groupby('month')},'by_side':{str(k):stat(x) for k,x in q.groupby('side')}}
 frames.to_csv(R/'turn_frames.csv',index=False)
 (R/'turn_study.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
