import sys,json,pandas as pd,numpy as np,pathlib
from study_turns import frames,outcome,stat
R=pathlib.Path(__file__).resolve().parent;res={}
for mode in ['strict_step','pivot_range_break','older_3_break','divergence']:
 rows=[];last={1:None,-1:None}
 for x in frames.itertuples(index=False):
  if not x.valid:continue
  for side in [1,-1]:
   price=x.pivot_low<=x.prior_low and x.low>x.pivot_low and x.close>x.pivot_close if side>0 else x.pivot_high>=x.prior_high and x.high<x.pivot_high and x.close<x.pivot_close
   dist=(x.close-x.pivot_low)/x.atr if side>0 else (x.pivot_high-x.close)/x.atr
   good=price and .15<=dist<=1.25 and side*x.raw_step_r>.01 and side*x.wave_step_r>.01 and side*x.raw_delta_pressure>0 and side*x.delta_step_norm>0
   if mode=='pivot_range_break':good=good and (x.close>x.pivot_high if side>0 else x.close<x.pivot_low)
   if mode=='older_3_break':
    from study_turns import h,l
    good=good and (x.close>h.iloc[x.index-3:x.index].max() if side>0 else x.close<l.iloc[x.index-3:x.index].min())
   if mode=='divergence':
    from study_turns import h,l,raw
    prev=x.index-2
    old= l.iloc[x.index-7:x.index-1].iloc[::-1].idxmin() if side>0 else h.iloc[x.index-7:x.index-1].iloc[::-1].idxmax()
    good=good and side*(raw.iloc[x.index-1]-raw.iloc[old])>.01*x.atr
   if not good:continue
   if last[side] is not None and (x.time-last[side]).total_seconds()<540:continue
   last[side]=x.time
   rows.append({'index':x.index,'bar_time':x.bar_time,'available_time':str(x.time+pd.Timedelta(minutes=3)),'pivot_time':x.pivot_time,'side':side,'score':3,'distance_atr':dist,'atr':x.atr})
 q=outcome(pd.DataFrame(rows));q.to_csv(R/f'turn_{mode}.csv',index=False);res[mode]={'all':stat(q),'by_month':{k:stat(z) for k,z in q.groupby('month')}}
(R/'confirmation_study.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:{'n':v['all']['signals'],'h5':v['all']['h5'],'months':{m:z['h5'] for m,z in v['by_month'].items()}} for k,v in res.items()},indent=2))
