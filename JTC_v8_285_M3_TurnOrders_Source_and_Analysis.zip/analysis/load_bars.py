from pathlib import Path
import pandas as pd

def load_bars():
    b=pd.read_csv(Path(__file__).with_name('input_bars.csv'),dtype=str,keep_default_na=False)
    b['bt']=pd.to_datetime(b['m3_bar_time'],format='%Y.%m.%d %H:%M:%S')
    return b.sort_values('bt').reset_index(drop=True)
