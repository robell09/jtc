import pandas as pd,numpy as np,json,pathlib
R=pathlib.Path(__file__).resolve().parent;s=pd.read_csv(R/'turn_divergence.csv');x=s[s.return_5.notna()].copy();x['day']=x.bar_time.str[:10]
a=[]
for _,z in x.groupby('day'):a.append([len(z),sum(z.return_5>0),z.return_5.sum()])
a=np.array(a);rng=np.random.default_rng(284);v=a[rng.integers(0,len(a),(5000,len(a)))].sum(axis=1)
q=lambda x:np.quantile(x,[.025,.975]).round(4).tolist()
# Leave signal decisions fixed; discard overlapping forward windows for a sensitivity check.
last=-100;rows=[]
for i,r in x.sort_values('index').iterrows():
 if r['index']>last+5:rows.append(i);last=r['index']
non=x.loc[rows]
result={'default_signal_count':len(s),'long_signals':int(sum(s.side==1)),'short_signals':int(sum(s.side==-1)),'valid_5bar_outcomes':len(x),'positive_5bar_outcomes':int(sum(x.return_5>0)),'positive_fraction':float((x.return_5>0).mean()),'mean_return_atr':float(x.return_5.mean()),'median_return_atr':float(x.return_5.median()),'barrier5_counts':x.barrier5.value_counts().to_dict(),'retrospective_pivot_survives_5bars':{'evaluated':int(s.pivot_survives5.notna().sum()),'survived':int(sum(s.pivot_survives5.fillna(False).astype(bool)))},'day_bootstrap_95pct_accuracy':q(v[:,1]/v[:,0]),'day_bootstrap_95pct_mean_return_atr':q(v[:,2]/v[:,0]),'nonoverlap':{'n':len(non),'positive_fraction':float((non.return_5>0).mean()),'mean_return_atr':float(non.return_5.mean())},'selection_warning':'Exploratory comparison of four causal confirmations on the same July/August run; not independent holdout or costed MT5 strategy','signal_timing':'pivot candle + one later closed M3 candle; available at close of later candle, not at historical pivot time'}
(R/'default_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
