from pathlib import Path
import pandas as pd,numpy as np,json,datetime as dt
R=Path(__file__).resolve().parent
b=pd.read_csv(R/'market_bars.csv');diag=pd.read_csv(R/'original_signal_diagnostics.csv').fillna('');t=pd.read_csv(R/'original_deals.csv',dtype={'position_id':str,'position_cycle_id':str}).fillna('');turn=pd.read_csv(R/'turn_signals.csv');N=len(b)
bt=pd.to_datetime(b.m3_bar_time);quote_time=bt.to_numpy();o,h,l,c=[b['m3_'+k].to_numpy() for k in ['open','high','low','close']];raw=b.assist_raw_macd.to_numpy();wave=b.assist_macd_wave.to_numpy();delta=b.assist_raw_delta.to_numpy();ema=b.assist_ema_delta.to_numpy();volume=b.m3_volume.to_numpy();spread=b.spread_points.to_numpy()*.01;atr=turn.atr.to_numpy();valid=turn.valid.to_numpy(bool)
entries=t[t.event_type.isin(['LIFECYCLE:ENTRY','LIFECYCLE:ADD_ENTRY'])].copy();closes=t[t.event_type.isin(['LIFECYCLE:CLOSE','LIFECYCLE:STOP_LOSS'])].copy();entries['entry_time']=pd.to_datetime(entries.time_server);closes['close_time']=pd.to_datetime(closes.time_server)
p=entries.set_index('position_id').join(closes.set_index('position_id')[['close_time','event_price','broker_position_final_pnl','event_type','blocked_reason']],rsuffix='_close');p['side']=np.where(p.direction=='LONG',1,-1);p['fee']=.21;p['broker_position_final_pnl']=pd.to_numeric(p.broker_position_final_pnl_close,errors='coerce')
p.to_csv(R/'position_ledger.csv')
completed=[k for k,g in p.groupby('position_cycle_id') if g.close_time.notna().all()];assert len(completed)==349;assert abs(p.loc[p.close_time.notna(),'broker_position_final_pnl'].sum()-8028.97)<1e-6

def swap(side,lot,start,end):
 date=start.date()+dt.timedelta(days=1);ans=0.
 while date<=end.date():
  prior=date-dt.timedelta(days=1)
  if prior.weekday()<5:ans+=round((-69.25 if side>0 else 17.1)*lot*(3 if prior.weekday()==2 else 1),2)
  date+=dt.timedelta(days=1)
 return ans

def mark(g,j,slip=0):
 ts=bt.iloc[j];side=int(g.side.iloc[0]);entered=g[g.entry_time<ts];closed=entered[entered.close_time<ts];live=entered[entered.close_time>=ts];done=float(closed.broker_position_final_pnl.sum());quote=o[j]+(spread[j-1] if side<0 else 0)-side*slip;marked=[]
 for pos in live.itertuples():marked.append(round(side*(quote-pos.event_price)*pos.event_volume*100+swap(side,pos.event_volume,pos.entry_time,ts)-pos.fee,2))
 return round(done+sum(marked),2),len(live),float(live.event_volume.sum()),done,marked

def alt_exit(g,j,slip=0,portion=1.,trim_add=False):
 if trim_add:
  ts=bt.iloc[j];side=int(g.side.iloc[0]);quote=o[j]+(spread[j-1] if side<0 else 0)-side*slip
  live=g[(g.entry_time<ts)&(g.close_time>=ts)&(g.event_type=='LIFECYCLE:ADD_ENTRY')].sort_values('entry_time').tail(2)
  ans=float(g.broker_position_final_pnl.sum())
  for pos in live.itertuples():
   early=round(side*(quote-pos.event_price)*pos.event_volume*100+swap(side,pos.event_volume,pos.entry_time,ts)-pos.fee,2)
   ans+=early-pos.broker_position_final_pnl
  return round(ans,2),0,len(live)
 # Entries at or after this quote are suppressed. Earlier actual closes remain actual.
 ts=bt.iloc[j];side=int(g.side.iloc[0]);used=g[g.entry_time<ts];done=used[used.close_time<ts];live=used[used.close_time>=ts];ans=float(done.broker_position_final_pnl.sum());quote=o[j]+(spread[j-1] if side<0 else 0)-side*slip
 for pos in live.itertuples():
  early=side*(quote-pos.event_price)*pos.event_volume*100+swap(side,pos.event_volume,pos.entry_time,ts)-pos.fee
  ans+=portion*round(early,2)+(1-portion)*pos.broker_position_final_pnl
 return round(ans,2),len(g[g.entry_time>=ts]),len(live)

# Closed-bar, zero-line-free, counter-direction predicates.
def evidence(i,held):
 side=-held;price=side*(c[i]-c[i-1])>0;mom=side*(raw[i]-raw[i-1])/atr[i]>.01;pressure=side*delta[i]>0 and side*(ema[i]-ema[i-1])>0
 raw2=sum(side*(raw[k]-raw[k-1])>0 for k in range(i-2,i+1))>=2
 net=side*(raw[i]-raw[i-2])>0 and side*(wave[i]-wave[i-2])>0
 swing=(h[i-1]>=max(h[i-7:i-1]) and h[i]<h[i-1] and c[i]<c[i-1]) if held>0 else (l[i-1]<=min(l[i-7:i-1]) and l[i]>l[i-1] and c[i]>c[i-1])
 break3=c[i]<min(l[i-3:i]) if held>0 else c[i]>max(h[i-3:i])
 shadow=diag.early_opposite_watch_pulse.iloc[i]=='YES' and diag.early_opposite_watch_side.iloc[i]==('SHORT' if held>0 else 'LONG')
 return {'shadow':shadow,'momentum':price and mom and pressure,'persistent':price and mom and raw2 and net,'swing':swing and mom and pressure,'shadow_break3':shadow and break3,'shadow_transition':shadow and diag.early_opposite_watch_stage.iloc[i] in ['TRANSITION','CONFIRMED'],'persistent_break3':price and mom and raw2 and net and break3}
obs=[];basecycles=[]
for k,g in p.groupby('position_cycle_id'):
 if k not in completed:continue
 g=g.sort_values('entry_time');side=int(g.side.iloc[0]);start=g.entry_time.min();end=g.close_time.max();final=round(float(g.broker_position_final_pnl.sum()),2);peak=0.;price_peak=0.;initial_fill=float(g.event_price.iloc[0]);initial_r=float(g.initial_r_distance.iloc[0])
 js=np.flatnonzero((quote_time>start.to_datetime64())&(quote_time<=end.to_datetime64()))
 for j in js:
  if j==0:continue
  net,live,lots,done,marked=mark(g,j)
  if not live:continue
  peak=max(peak,net);quote=o[j]+(spread[j-1] if side<0 else 0);price_peak=max(price_peak,side*(quote-initial_fill));peak_r=price_peak/initial_r;i=j-1
  if not valid[i] or i<8:continue
  evidence_=evidence(i,side);unit=lots*100*atr[i];keep=net/peak if peak>0 else np.nan
  canonical=diag.watch_event.iloc[i]=='YES' and diag.watch_side.iloc[i]==('SHORT' if side>0 else 'LONG')
  obs.append({'cycle':k,'j':int(j),'confirm_index':i,'signal_time':str(bt.iloc[i]),'available_time':str(bt.iloc[j]),'side':side,'net_if_exit':net,'observed_peak':peak,'keep_fraction':keep,'current_lots':lots,'live_add_positions':int(((g.entry_time<bt.iloc[j])&(g.close_time>=bt.iloc[j])&(g.event_type=='LIFECYCLE:ADD_ENTRY')).sum()),'profit_atr':net/unit,'peak_atr':peak/unit,'initial_peak_r':peak_r,'legacy_peak80_quote_breach':bool(peak_r>=.8 and side*(quote-initial_fill)<=.8*price_peak),'pullback_atr':(peak-net)/unit,'baseline_final':final,'baseline_close_time':str(end),'lead_minutes_to_final_close':(end-bt.iloc[j]).total_seconds()/60,'canonical_opposite':canonical,'raw_step_r':side*(raw[i]-raw[i-1])/atr[i],'wave_side':float(wave[i]),**evidence_})
 basecycles.append({'cycle':k,'side':side,'entry_time':str(start),'close_time':str(end),'baseline_net':final,'observed_peak':max(peak,final),'giveback':max(peak,final)-final,'positions':len(g),'all_SL':bool((g.event_type_close=='LIFECYCLE:STOP_LOSS').all())})
x=pd.DataFrame(obs);base=pd.DataFrame(basecycles);
watch_times={side:[bt.iloc[i+1] for i in range(N-1) if diag.watch_event.iloc[i]=='YES' and diag.watch_side.iloc[i]==('SHORT' if side>0 else 'LONG')] for side in [1,-1]}
leads=[]
for row in x.itertuples():
 ts=pd.Timestamp(row.available_time);end=pd.Timestamp(row.baseline_close_time);later=[w for w in watch_times[row.side] if ts<w<=end]
 leads.append((later[0]-ts).total_seconds()/60 if later else np.nan)
x['lead_to_opposite_WATCH_minutes']=leads;
x.to_csv(R/'decision_observations.csv',index=False);base.to_csv(R/'baseline_cycles.csv',index=False)
# First matching candidate before baseline close, with positive profit and optional peak/pullback gates.
variants=[dict(name='BASELINE',signal=None)]
for signal in ['shadow','momentum','persistent','swing','shadow_break3','persistent_break3','shadow_transition']:
 variants.append(dict(name=f'{signal}_profit_only',signal=signal,min_peak_atr=0,keep=1.,pullback=0))
 for keep in [.90,.80]:variants.append(dict(name=f'{signal}_peak1_keep{int(keep*100)}',signal=signal,min_peak_atr=1.,keep=keep,pullback=.25))
# Separate controls isolate a profit floor without counter signal. This model exits on quote, not an intrabar stop.
for keep in [.9,.8]:variants.append(dict(name=f'profit_floor_peak1_keep{int(keep*100)}',signal='any',min_peak_atr=1.,keep=keep,pullback=.25))
# Stress exits and a whole-ticket latest ADD reduction overlay; no fractional lots.
variants += [dict(name='shadow_peak1_keep80_slip015',signal='shadow',min_peak_atr=1.,keep=.8,pullback=.25,slip=.15),dict(name='persistent_peak1_keep80_slip015',signal='persistent',min_peak_atr=1.,keep=.8,pullback=.25,slip=.15),dict(name='shadow_peak1_keep80_trim_latest2_ADD',signal='shadow',min_peak_atr=1.,keep=.8,pullback=.25,trim_add=True)]
variants += [dict(name='shadow_transition_peak1_keep80_trim_latest2_ADD',signal='shadow_transition',min_peak_atr=1.,keep=.8,pullback=.25,trim_add=True),dict(name='shadow_peak1_keep90_trim_latest2_ADD',signal='shadow',min_peak_atr=1.,keep=.9,pullback=.25,trim_add=True)]
variants += [dict(name='shadow_R08_keep80',signal='shadow',min_peak_atr=0,keep=.8,pullback=.25,min_peak_r=.8),dict(name='shadow_transition_R08_keep80',signal='shadow_transition',min_peak_atr=0,keep=.8,pullback=.25,min_peak_r=.8),dict(name='shadow_R08_keep80_trim_latest2_ADD',signal='shadow',min_peak_atr=0,keep=.8,pullback=.25,min_peak_r=.8,trim_add=True),dict(name='legacy_Peak80_quote_control',signal='legacy_peak80_quote_breach',min_peak_atr=0,keep=1.,pullback=0,allow_loss=True)]
summary=[];ledger=[];best_ids=set(base.nlargest(5,'baseline_net').cycle)
for spec in variants:
 vals=[];triggered=0;gains=0;hurt=0;missedadds=0;leads=[];topdelta=0;peakloss=0
 for k,g in p.groupby('position_cycle_id'):
  if k not in completed:continue
  final=round(float(g.broker_position_final_pnl.sum()),2);dec=x[x.cycle==k];chosen=None
  if spec['signal']:
   mask=pd.Series(True,index=dec.index) if spec['signal']=='any' else dec[spec['signal']].astype(bool)
   mask &= ((dec.net_if_exit>0)|spec.get('allow_loss',False))&(dec.peak_atr>=spec['min_peak_atr'])&(dec.keep_fraction<=spec['keep'])&(dec.pullback_atr>=spec['pullback'])&(dec.lead_minutes_to_final_close>0)&~dec.canonical_opposite
   if spec.get('min_peak_r',0):mask &= dec.initial_peak_r>=spec['min_peak_r']
   if spec.get('trim_add',False):mask &= dec.live_add_positions>0
   filtered=dec[mask]
   if len(filtered):chosen=filtered.iloc[0]
  new=final;skip=0;live=0
  if chosen is not None:
   new,skip,live=alt_exit(g,int(chosen.j),spec.get('slip',0),spec.get('portion',1),spec.get('trim_add',False));triggered+=1;gains+=int(new>final+.01);hurt+=int(new<final-.01);missedadds+=skip;leads.append(float(chosen.lead_minutes_to_final_close));peakloss+=float(chosen.observed_peak)-new
  diff=round(new-final,2);topdelta+=diff if k in best_ids else 0;vals.append(new)
  ledger.append({'variant':spec['name'],'cycle':k,'baseline_net':final,'overlay_net':new,'delta':diff,'triggered':chosen is not None,'exit_time':str(chosen.available_time) if chosen is not None else '', 'lead_to_opposite_WATCH_minutes':float(chosen.lead_to_opposite_WATCH_minutes) if chosen is not None else np.nan,'lead_minutes':float(chosen.lead_minutes_to_final_close) if chosen is not None else 0,'peak_at_trigger':float(chosen.observed_peak) if chosen is not None else np.nan,'suppressed_later_entries':skip,'live_at_exit':live,'original_close_time':str(g.close_time.max()),'side':int(g.side.iloc[0]),'top5_original':k in best_ids})
 arr=np.array(vals);cum=np.r_[0,arr.cumsum()];w=arr[arr>0].sum();loss=-arr[arr<0].sum()
 summary.append({'variant':spec['name'],'net':round(arr.sum(),2),'delta_vs_baseline':round(arr.sum()-8028.97,2),'cycle_PF':round(w/loss,4),'cycle_win_pct':round((arr>0).mean()*100,2),'early_exit_cycles':triggered,'improved_cycles':gains,'worsened_cycles':hurt,'suppressed_later_entries':missedadds,'median_lead_minutes':float(np.median(leads)) if leads else 0,'top5_original_delta':round(topdelta,2),'cycle_realized_DD_in_original_order':round((np.maximum.accumulate(cum)-cum).max(),2)})
out=pd.DataFrame(summary);out.to_csv(R/'comparison.csv',index=False);pd.DataFrame(ledger).to_csv(R/'cycle_overlay_ledger.csv',index=False)
# Evidence timing count and candidate opportunity outcomes without choosing future-optimal bars.
cand=[]
for name in ['shadow','momentum','persistent','swing','shadow_break3','persistent_break3']:
 z=x[x[name]&~x.canonical_opposite&(x.lead_minutes_to_final_close>0)].drop_duplicates('cycle')
 cand.append({'candidate':name,'first_candidate_cycles':len(z),'profitable_at_first':int((z.net_if_exit>0).sum()),'first_exit_improves_cycles':int((z.net_if_exit>z.baseline_final).sum()),'first_exit_worsens_cycles':int((z.net_if_exit<z.baseline_final).sum()),'median_lead_to_final_minutes':float(z.lead_minutes_to_final_close.median()),'median_peak_retention_at_first':float(z.keep_fraction.median())})
pd.DataFrame(cand).to_csv(R/'candidate_timing.csv',index=False)
meta={'completed_cycles':349,'baseline_net':8028.97,'actual_positions_closed':1128,'last_unconfirmed_cycle_excluded':1,'diagnostic_pulses':int((diag.early_opposite_watch_pulse=='YES').sum()),'observations':len(x),'source_peak_nonzero_bars':int((pd.to_numeric(diag.m3_profit_peak_r)!=0).sum()),'source_lock_applied_bars':int((diag.m3_profit_lock_applied=='YES').sum()),'positive_peak_cycles':int((base.observed_peak>0).sum()),'top5_original_net':round(base.nlargest(5,'baseline_net').baseline_net.sum(),2),'variants':len(variants)}
(R/'summary.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2));print(out.to_string(index=False));print(pd.DataFrame(cand).to_string(index=False))
