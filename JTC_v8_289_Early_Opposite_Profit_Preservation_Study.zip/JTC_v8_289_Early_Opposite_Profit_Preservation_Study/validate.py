from pathlib import Path
import pandas as pd,numpy as np,json,ast,datetime as dt
R=Path(__file__).resolve().parent;p=pd.read_csv(R/'position_ledger.csv',dtype={'position_id':str});p.entry_time=pd.to_datetime(p.entry_time);p.close_time=pd.to_datetime(p.close_time);b=pd.read_csv(R/'market_bars.csv');d=pd.read_csv(R/'original_signal_diagnostics.csv').fillna('');turn=pd.read_csv(R/'turn_signals.csv');x=pd.read_csv(R/'decision_observations.csv');z=pd.read_csv(R/'cycle_overlay_ledger.csv');summary=pd.read_csv(R/'comparison.csv');env={'pd':pd,'np':np,'dt':dt,'bt':pd.to_datetime(b.m3_bar_time),'o':b.m3_open.to_numpy(),'spread':b.spread_points.to_numpy()*.01,'diag':d,'atr':turn.atr.to_numpy(),'h':b.m3_high.to_numpy(),'l':b.m3_low.to_numpy(),'c':b.m3_close.to_numpy(),'raw':b.assist_raw_macd.to_numpy(),'wave':b.assist_macd_wave.to_numpy(),'delta':b.assist_raw_delta.to_numpy(),'ema':b.assist_ema_delta.to_numpy()}
a=ast.parse((R/'analyze.py').read_text());funcs=[f for f in a.body if isinstance(f,ast.FunctionDef) and f.name in ['swap','mark','evidence']];exec(compile(ast.Module(body=funcs,type_ignores=[]),'analysis_functions','exec'),env)
checks=[];closed=p[p.close_time.notna()];pred=[]
for row in closed.itertuples():pred.append(round(row.side*(row.event_price_close-row.event_price)*row.event_volume*100+env['swap'](row.side,row.event_volume,row.entry_time,row.close_time)-row.fee,2))
assert np.allclose(pred,closed.broker_position_final_pnl,atol=.00001);checks.append('all 1128 actual position PnLs match fee and swap model')
assert summary.loc[summary.variant=='BASELINE','net'].iloc[0]==8028.97
for q in summary.itertuples():
 g=z[z.variant==q.variant];assert len(g)==349;assert abs(round(g.overlay_net.sum(),2)-q.net)<.001;assert np.allclose(g.overlay_net-g.baseline_net,g.delta,atol=.001)
 assert (g.loc[g.triggered,'lead_minutes']>0).all()
checks.append('baseline and all 33 overlay ledgers reconcile exactly across 349 completed cycles')
# No future final PnL, future entry price or future close time may affect as-of mark and peak inputs.
for row in x.iloc[::max(1,len(x)//35)].itertuples():
 g=p[p.position_cycle_id==row.cycle].copy();j=int(row.j);ts=env['bt'].iloc[j];before=env['mark'](g,j);mut=g.copy();mut.loc[mut.entry_time>=ts,'event_price']+=100000;mut.loc[mut.close_time>=ts,'broker_position_final_pnl']+=100000;mut.loc[mut.close_time>=ts,'close_time']+=pd.Timedelta(days=100);after=env['mark'](mut,j)
 assert before==after
checks.append('36 as-of portfolio checks ignore unknown future entries, exits and final PnL')
indices=[i for i in range(8,1000) if bool(turn.valid.iloc[i])]
full={side:{i:env['evidence'](i,side) for i in indices} for side in [-1,1]}
for k in ['o','spread','atr','h','l','c','raw','wave','delta','ema']:env[k]=env[k][:700]
env['diag']=d.iloc[:700]
for side in [-1,1]:assert {i:env['evidence'](i,side) for i in indices if i<700}=={i:q for i,q in full[side].items() if i<700}
checks.append('counter-direction predicates for both held sides are invariant to a 700-bar prefix cutoff')
(R/'validation.json').write_text(json.dumps({'status':'passed','checks':checks},indent=2));print(json.dumps(checks,indent=2))
