# 분석 재현

이 폴더의 input_bars.csv는 사용자가 제공한 v8.282 원본 CSV의 BAR:M3_CANONICAL 행에서 필요한 10개 컬럼만 추출한 자료입니다. 14,639봉이며 데이터 순서를 보존했습니다. 원본 파일명과 run 범위는 기존 분석과 동일합니다. 새 EA에서 생성한 데이터가 아닙니다.

Python 3.12, pandas 2.2.3, numpy는 requirements-analysis.txt의 버전을 사용했습니다. matplotlib는 차트 생성에만 필요합니다. 실행 예:

```bash
python analysis/inspect_indicators.py
python analysis/study_turns.py
python analysis/check_confirmation.py
python analysis/summarize_default.py
python analysis/plot_turns.py
python tests/validate.py
```

validate.py는 g++ C++17이 필요합니다. MetaEditor를 호출하지 않습니다. turn_divergence.csv가 기본 조건의 신호 목록입니다. turn_frames.csv는 처음 비교한 단순 relief 프레임으로, 기본 strict+divergence 신호 그 자체가 아닙니다. default_summary.json과 confirmation_study.json을 함께 확인하세요.

5봉 방향 수익은 신호 계산 당시 마지막 확정봉의 종가부터 이후 5개 연속봉 뒤 종가까지의 ATR 정규화 이동입니다. 거래비용·실제 다음 tick 체결을 적용하지 않았습니다. pivot_survives5는 미래 가격으로 평가한 label이며 신호 조건에 사용되지 않습니다. 같은 날짜를 5,000회 재표집한 bootstrap은 탐색 불확실성 추정이고 조건 선택 편향을 교정하지 않습니다.

첫 조건(감속만 확인)의 결과가 좋지 않아 현재 step 상승/하락, pivot range break, older-three break, divergence를 비교했습니다. 최종 조건 선택에 같은 자료를 사용했으므로 전체 표본 외 성과로 부르지 않습니다. 예제 차트는 수익 결과를 골라 보여주지 않고, 첫 유효 LONG과 첫 유효 SHORT을 표시합니다.


v8.286 추가 검증: `python tests/validate_orders.py`(52개 주문 모의 시나리오), `python tests/validate_direction.py`(실제 MACD base 컬럼으로 14,639봉 방향신호 재현). input_bars.csv는 11컬럼으로 확장됐습니다. 방향신호 후보는 실제 ADD 체결이나 거래 수익을 뜻하지 않습니다.
