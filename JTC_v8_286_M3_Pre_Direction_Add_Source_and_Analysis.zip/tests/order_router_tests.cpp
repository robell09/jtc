
#include <vector>
#include <string>
#include <cmath>
#include <cstdio>
#include <cassert>
#include <iostream>
using string=std::string;using datetime=long long;using ulong=unsigned long;
const int PERIOD_M3=3,SYMBOL_ASK=1,SYMBOL_BID=2,POSITION_SYMBOL=1,POSITION_MAGIC=2,POSITION_IDENTIFIER=3,TIME_DATE=1,TIME_SECONDS=2;
const int JTA_CYCLE_IDLE=0,JTA_CYCLE_EXIT_PENDING=1,JTA_CYCLE_ENTRY_PENDING=2,JTA_CYCLE_POSITION_OPEN=3;
string _Symbol="GOLD";ulong InpMagicNumber=123;
bool InpTurnAddOnPre=true,InpTurnAddOnDirection=true;
int g_max_additional_entries=0,g_additional_entry_filled_count=0,g_add_same_direction_signal_count=0,adds=0,bars_since=1;
bool g_add_order_in_progress=false,g_add_position_sync_pending=false,add_ok=true;
string g_add_second_signal_event_id;
int BarsSinceLastEntry(){return bars_since;}
bool InpTurnTradeEnabled=true,InpTurnPreEnabled=true,InpTurnReverseOnOpposite=true,InpSystemEnabled=true,g_auto_trading=true;
double InpTurnMinReboundATR=.15,InpTurnMaxDistanceATR=1.25;
bool g_m3_auto_execution_context_active=false,g_m3_auto_order_authority_active=false,g_exit_order_in_progress=false,g_entry_order_in_progress=false;
string g_csv_order_signal_source,g_current_long_signal_event_id,g_current_short_signal_event_id,g_exit_source_event_id,g_status;
int g_csv_order_signal_side=0,g_range_long_signal_count=0,g_range_short_signal_count=0,g_last_long_score=0,g_last_short_score=0;
datetime g_csv_order_signal_time=0;
struct Assist {bool turn_direction_valid=false,turn_direction_signal=false;datetime turn_direction_bar=1000;int turn_direction_side=1;bool turn_pre_data_valid=true,turn_pre_signal=true;datetime turn_pre_confirm_bar=1000,turn_pre_available_time=1180;int turn_pre_side=1;double turn_pre_atr14=1,turn_pre_pivot_price=10;} g_assist_state;
struct Cycle {int state=0;} g_trade_cycle;
datetime latest=1000,now=1180;double ask=10.8,bid=10.7;int held=0,entries=0,exits=0,allowed_side=0;
bool permission=true,close_ok=true,entry_ok=true;
struct Pos{ulong id;string symbol;ulong magic;bool open;};std::vector<Pos> positions;int selected=-1;
string IntegerToString(long v){return std::to_string(v);}string TimeToString(datetime v,int){return std::to_string(v);}
const char* arg(const string& v){return v.c_str();}template<class T>T arg(T v){return v;}
template<class... A>string StringFormat(const char* f,A...a){char b[2048];std::snprintf(b,sizeof(b),f,arg(a)...);return b;}
template<class T>int ArraySize(const std::vector<T>&v){return int(v.size());}
template<class T>void ArrayResize(std::vector<T>&v,int n){v.resize(n);}
bool MathIsValidNumber(double v){return std::isfinite(v);}
datetime iTime(const string&,int,int){return latest;}datetime TimeCurrent(){return now;}
double SymbolInfoDouble(const string&,int what){return what==SYMBOL_ASK?ask:bid;}
int ManagedPositionSide(){return held;}bool AutoDirectionAllows(int side){return allowed_side==0||allowed_side==side;}
bool JTATradePermissionAllowed(string& reason){reason="TRADE_PERMISSION";return permission;}
void Print(const string&){}
template<class...A>void WriteUnifiedOrderSignalAudit(A...){}
void TradeCycleEnsure(int,const string&){g_trade_cycle.state=4;}void TradeCycleClear(const string&){g_trade_cycle.state=0;}
bool EntryEngineSubmitInitial(int side,int score,const string& reason,double price,bool append){
 assert(g_m3_auto_execution_context_active && score==3 && price>0 && !append);
 assert(reason.find("TURN PRE INITIAL")!=string::npos);entries++;
 if(!permission || !entry_ok)return false;
 held=side;g_trade_cycle.state=JTA_CYCLE_POSITION_OPEN;return true;
}
bool EntryEngineSubmitAdditional(int side,int stage,const string& reason){
 assert(g_m3_auto_execution_context_active && reason.find("TURN ADD")!=string::npos);
 assert(stage==g_additional_entry_filled_count+1 && g_add_second_signal_event_id!="");
 adds++;if(!add_ok || !permission)return false;
 g_additional_entry_filled_count++;assert(side==held);return true;
}
bool CloseManagedPosition(const string& reason){
 assert(reason.find("TURN PRE OPPOSITE EXIT")!=string::npos);exits++;
 if(!close_ok)return false;
 for(auto &p:positions)if(p.symbol==_Symbol&&p.magic==InpMagicNumber)p.open=false;
 held=0;g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;g_exit_order_in_progress=true;return true;
}
int PositionsTotal(){return positions.size();}ulong PositionGetTicket(int i){selected=i;return i+1;}
bool PositionSelectByTicket(ulong t){selected=int(t)-1;return selected>=0&&selected<int(positions.size());}
string PositionGetString(int){return positions.at(selected).symbol;}
long PositionGetInteger(int what){return what==POSITION_MAGIC?positions.at(selected).magic:positions.at(selected).id;}
bool DataExportPositionIdentifierOpen(ulong id){for(auto&p:positions)if(p.id==id)return p.open;return false;}
#ifndef JTC_TURN_ORDER_ENGINE_MQH
#define JTC_TURN_ORDER_ENGINE_MQH
// Exclusive TURN PRE INITIAL/EXIT + same-side PRE/DIRECTION ADD router.
datetime g_turn_order_consumed_bar=0;
datetime g_turn_order_add_attempt_bar=0,g_turn_direction_consumed_bar=0;
datetime g_turn_order_pending_bar=0;
int g_turn_order_pending_side=0;
bool g_turn_order_flat_confirmed=false;
string g_turn_order_pending_event="";
std::vector<ulong> g_turn_order_exit_ids;
std::vector<bool> g_turn_order_exit_seen;

void JTC_TurnOrderCancelPending()
{
   g_turn_order_pending_bar=0; g_turn_order_pending_side=0;
   g_turn_order_flat_confirmed=false; g_turn_order_pending_event="";
   ArrayResize(g_turn_order_exit_ids,0); ArrayResize(g_turn_order_exit_seen,0);
}
void JTC_TurnOrderReset()
{
   g_turn_order_consumed_bar=0;
   g_turn_order_add_attempt_bar=0;g_turn_direction_consumed_bar=0;
   JTC_TurnOrderCancelPending();
}
void JTC_TurnOrderSource(const int side,const datetime bar,const string event_id)
{
   g_csv_order_signal_source="TURN_PRE";
   g_csv_order_signal_side=side; g_csv_order_signal_time=bar;
   if(side>0)
   {
      g_current_long_signal_event_id=event_id;
      g_range_long_signal_count=3; g_last_long_score=3;
   }
   else
   {
      g_current_short_signal_event_id=event_id;
      g_range_short_signal_count=3; g_last_short_score=3;
   }
}
void JTC_TurnOrderAudit(const int side,const string event_id,const string action,
                        const string result,const string reason)
{
   g_status="TURN PRE "+action+" | "+result+" | "+reason;
   Print(g_status);
   WriteUnifiedOrderSignalAudit("TURN_ORDER",event_id,action,side,3,3,
      result,reason,false,false,0,0);
}
// Called only AFTER the existing exit-deal lifecycle has completed/reset.
// All captured position identifiers must report a final close before reversing.
void JTC_TurnOrderOnExitDeal(const ulong position_id)
{
   if(g_turn_order_pending_side==0 || position_id==0) return;
   for(int i=0;i<ArraySize(g_turn_order_exit_ids);++i)
      if(g_turn_order_exit_ids[i]==position_id && !DataExportPositionIdentifierOpen(position_id))
         g_turn_order_exit_seen[i]=true;
   if(ArraySize(g_turn_order_exit_ids)==0 || ManagedPositionSide()!=0) return;
   for(int i=0;i<ArraySize(g_turn_order_exit_seen);++i)
      if(!g_turn_order_exit_seen[i]) return;
   g_turn_order_flat_confirmed=true;
}
bool JTC_TurnOrderEntry(const int side,const datetime bar,const string event_id)
{
   if(!AutoDirectionAllows(side))
   {JTC_TurnOrderAudit(side,event_id,"INITIAL","BLOCKED","AUTO_DIRECTION");return false;}
   const double quote=SymbolInfoDouble(_Symbol,side>0 ? SYMBOL_ASK : SYMBOL_BID);
   const double atr=g_assist_state.turn_pre_atr14;
   const double distance=side*(quote-g_assist_state.turn_pre_pivot_price);
   if(quote<=0.0 || !MathIsValidNumber(quote) || !MathIsValidNumber(atr) ||
      !MathIsValidNumber(g_assist_state.turn_pre_pivot_price) || atr<=0.0 ||
      distance<atr*InpTurnMinReboundATR || distance>atr*InpTurnMaxDistanceATR)
   {JTC_TurnOrderAudit(side,event_id,"INITIAL","BLOCKED","LIVE_PRICE_OUTSIDE_TURN_ATR_RANGE");return false;}
   // Never start a new cycle while the old close callback or an entry sync is pending.
   if(g_exit_order_in_progress || g_entry_order_in_progress || ManagedPositionSide()!=0 ||
      g_trade_cycle.state==JTA_CYCLE_EXIT_PENDING || g_trade_cycle.state==JTA_CYCLE_ENTRY_PENDING ||
      g_trade_cycle.state==JTA_CYCLE_POSITION_OPEN)
   {JTC_TurnOrderAudit(side,event_id,"INITIAL","BLOCKED","POSITION_OR_LIFECYCLE_PENDING");return false;}
   JTC_TurnOrderSource(side,bar,event_id);
   TradeCycleEnsure(side,event_id);
   const bool old_context=g_m3_auto_execution_context_active;
   g_m3_auto_execution_context_active=true;
   // TURN-specific classification: retain percentage SL, never stale M3 structural SL.
   const string reason=StringFormat("TURN PRE INITIAL %s | SIGNAL=%s | BAR=%s",
      side>0 ? "LONG" : "SHORT",event_id,TimeToString(bar,TIME_DATE|TIME_SECONDS));
   const bool ok=EntryEngineSubmitInitial(side,3,reason,quote,false);
   g_m3_auto_execution_context_active=old_context;
   if(!ok && ManagedPositionSide()==0 && g_trade_cycle.state!=JTA_CYCLE_ENTRY_PENDING &&
      g_trade_cycle.state!=JTA_CYCLE_POSITION_OPEN)
      TradeCycleClear("TURN_INITIAL_NOT_SUBMITTED");
   JTC_TurnOrderAudit(side,event_id,"INITIAL",ok ? "SUBMITTED" : "FAILED_OR_BLOCKED",reason);
   return ok;
}
bool JTC_TurnOrderAdd(const int side,const datetime bar,const string event_id,const string source)
{
   if(bar<=0 || bar<=g_turn_order_add_attempt_bar) return false;
   // One attempt per completed bar, shared across PRE and DIRECTION, including failures.
   g_turn_order_add_attempt_bar=bar;
   if((source=="TURN_PRE" && !InpTurnAddOnPre) ||
      (source=="DIRECTION" && !InpTurnAddOnDirection))
   {JTC_TurnOrderAudit(side,event_id,"ADD","DISABLED",source);return false;}
   if(g_max_additional_entries<=0 || g_additional_entry_filled_count>=g_max_additional_entries)
   {JTC_TurnOrderAudit(side,event_id,"ADD","BLOCKED","MAX_ADD_CAPACITY");return false;}
   if(!AutoDirectionAllows(side) || ManagedPositionSide()!=side ||
      g_turn_order_pending_side!=0 || g_exit_order_in_progress || g_entry_order_in_progress ||
      g_add_order_in_progress || g_add_position_sync_pending ||
      g_trade_cycle.state==JTA_CYCLE_EXIT_PENDING || g_trade_cycle.state==JTA_CYCLE_ENTRY_PENDING ||
      BarsSinceLastEntry()<1)
   {JTC_TurnOrderAudit(side,event_id,"ADD","BLOCKED","SIDE_OR_LIFECYCLE_OR_SAME_ENTRY_BAR");return false;}
   JTC_TurnOrderSource(side,bar,event_id);
   g_csv_order_signal_source=source;
   g_add_second_signal_event_id=event_id;
   g_add_same_direction_signal_count=1;
   const int stage=g_additional_entry_filled_count+1;
   const string reason=StringFormat("TURN ADD%d %s | SOURCE=%s | SIGNAL=%s | BAR=%s",
      stage,side>0 ? "LONG" : "SHORT",source,event_id,TimeToString(bar,TIME_DATE|TIME_SECONDS));
   const bool old_context=g_m3_auto_execution_context_active;
   g_m3_auto_execution_context_active=true;
   const bool ok=EntryEngineSubmitAdditional(side,stage,reason);
   g_m3_auto_execution_context_active=old_context;
   JTC_TurnOrderAudit(side,event_id,"ADD",ok ? "SUBMITTED" : "FAILED_OR_BLOCKED",reason);
   return ok;
}
void JTC_TurnOrderProcessPreTick()
{
   if(!InpTurnTradeEnabled) return;
   g_m3_auto_order_authority_active=false;
   const datetime latest=iTime(_Symbol,PERIOD_M3,1);
   const bool enabled=InpSystemEnabled && g_auto_trading && InpTurnPreEnabled;
   if(g_turn_order_pending_side!=0)
   {
      if(!enabled || latest!=g_turn_order_pending_bar)
      {
         JTC_TurnOrderAudit(g_turn_order_pending_side,g_turn_order_pending_event,
            "REVERSE","CANCELLED",!enabled ? "SYSTEM_OR_AUTO_OFF" : "SIGNAL_EXPIRED");
         JTC_TurnOrderCancelPending();
      }
      else if(g_turn_order_flat_confirmed && ManagedPositionSide()==0)
      {
         const int side=g_turn_order_pending_side;
         const datetime bar=g_turn_order_pending_bar;
         const string event_id=g_turn_order_pending_event;
         JTC_TurnOrderCancelPending(); // exactly one attempt on a later tick
         JTC_TurnOrderEntry(side,bar,event_id);
      }
   }
   if(!g_assist_state.turn_pre_data_valid || !g_assist_state.turn_pre_signal) return;
   const datetime bar=g_assist_state.turn_pre_confirm_bar;
   const int side=g_assist_state.turn_pre_side;
   if(bar<=0 || bar<=g_turn_order_consumed_bar || (side!=1 && side!=-1)) return;
   // Consume while OFF as well: switching AUTO ON mid-bar must not resurrect an old signal.
   g_turn_order_consumed_bar=bar;
   const string event_id="TURN-"+IntegerToString((long)bar)+(side>0 ? "-L" : "-S");
   if(!enabled || bar!=latest || TimeCurrent()<g_assist_state.turn_pre_available_time)
   {JTC_TurnOrderAudit(side,event_id,"SIGNAL","IGNORED",!enabled ? "SYSTEM_OR_AUTO_OFF" : "STALE_OR_NOT_CLOSED");return;}
   const int held=ManagedPositionSide();
   if(held==side)
   {JTC_TurnOrderAdd(side,bar,event_id,"TURN_PRE");return;}
   if(held==0)
   {JTC_TurnOrderEntry(side,bar,event_id);return;}
   string permission="";
   if(!JTATradePermissionAllowed(permission))
   {JTC_TurnOrderAudit(side,event_id,"EXIT","BLOCKED",permission);return;}
   JTC_TurnOrderSource(side,bar,event_id);
   JTC_TurnOrderCancelPending();
   g_turn_order_pending_side=side; g_turn_order_pending_bar=bar;
   g_turn_order_pending_event=event_id;
   // Capture all EA-owned tickets, including any old ADD layers restored on attachment.
   for(int i=PositionsTotal()-1;i>=0;--i)
   {
      const ulong ticket=PositionGetTicket(i);
      if(ticket==0 || !PositionSelectByTicket(ticket) ||
         PositionGetString(POSITION_SYMBOL)!=_Symbol ||
         (ulong)PositionGetInteger(POSITION_MAGIC)!=InpMagicNumber) continue;
      const int n=ArraySize(g_turn_order_exit_ids);
      ArrayResize(g_turn_order_exit_ids,n+1); ArrayResize(g_turn_order_exit_seen,n+1);
      g_turn_order_exit_ids[n]=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
      g_turn_order_exit_seen[n]=false;
   }
   g_exit_source_event_id=event_id;
   const bool ok=CloseManagedPosition("TURN PRE OPPOSITE EXIT | SIGNAL="+event_id);
   if(!ok || !InpTurnReverseOnOpposite)
      JTC_TurnOrderCancelPending();
   JTC_TurnOrderAudit(side,event_id,"EXIT",ok ? "SUBMITTED" : "FAILED",
      ok && InpTurnReverseOnOpposite ? "WAIT_FOR_ALL_EXIT_DEALS_THEN_REVERSE" : "NO_REVERSE");
}
void JTC_TurnOrderProcessTick()
{
   if(!InpTurnTradeEnabled) return;
   JTC_TurnOrderProcessPreTick(); // PRE owns INITIAL/EXIT, and has ADD priority.
   if(!g_assist_state.turn_direction_valid || !g_assist_state.turn_direction_signal) return;
   const datetime bar=g_assist_state.turn_direction_bar;
   const int side=g_assist_state.turn_direction_side;
   if(bar<=0 || bar<=g_turn_direction_consumed_bar || (side!=1 && side!=-1)) return;
   g_turn_direction_consumed_bar=bar; // OFF events and blocked events stay consumed.
   const string event_id="TURN-DIR-"+IntegerToString((long)bar)+(side>0 ? "-L" : "-S");
   if(!InpSystemEnabled || !g_auto_trading || !InpTurnPreEnabled ||
      bar!=iTime(_Symbol,PERIOD_M3,1) || TimeCurrent()<bar+180 ||
      g_turn_order_pending_side!=0 || bar==g_turn_order_consumed_bar)
   {JTC_TurnOrderAudit(side,event_id,"DIRECTION","IGNORED","OFF_STALE_OR_PRE_PRIORITY");return;}
   if(ManagedPositionSide()!=side)
   {JTC_TurnOrderAudit(side,event_id,"DIRECTION","IGNORED","ADD_ONLY_SAME_HELD_SIDE");return;}
   JTC_TurnOrderAdd(side,bar,event_id,"DIRECTION");
}
#endif

void reset(int side=1){
 JTC_TurnOrderReset();adds=0;bars_since=1;g_max_additional_entries=0;g_additional_entry_filled_count=0;
 g_add_order_in_progress=g_add_position_sync_pending=false;InpTurnAddOnPre=InpTurnAddOnDirection=add_ok=true;g_assist_state=Assist();g_assist_state.turn_pre_side=side;
 if(side<0){g_assist_state.turn_pre_pivot_price=11.5;}
 latest=1000;now=1180;ask=10.8;bid=10.7;held=0;entries=exits=0;allowed_side=0;
 permission=close_ok=entry_ok=true;positions.clear();g_trade_cycle.state=0;
 g_exit_order_in_progress=g_entry_order_in_progress=false;
 g_m3_auto_execution_context_active=false;InpTurnTradeEnabled=InpTurnPreEnabled=InpSystemEnabled=g_auto_trading=InpTurnReverseOnOpposite=true;
}
void ack(ulong id){g_trade_cycle.state=0;g_exit_order_in_progress=false;JTC_TurnOrderOnExitDeal(id);}
int main(){
 int cases=0;
 reset();JTC_TurnOrderProcessTick();assert(entries==1&&held==1&&g_csv_order_signal_source=="TURN_PRE"&&!g_m3_auto_execution_context_active);JTC_TurnOrderProcessTick();assert(entries==1);cases++;
 reset(-1);JTC_TurnOrderProcessTick();assert(entries==1&&held==-1);cases++;
 reset();held=1;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);JTC_TurnOrderProcessTick();assert(entries==0);ack(55);assert(entries==0);JTC_TurnOrderProcessTick();assert(entries==1&&held==1);JTC_TurnOrderProcessTick();assert(entries==1);cases++;
 reset(-1);held=1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==1&&held==-1);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true},{56,"GOLD",123,true},{60,"GOLD",999,true},{61,"WTI",123,true}};JTC_TurnOrderProcessTick();assert(g_turn_order_exit_ids.size()==2);ack(55);JTC_TurnOrderProcessTick();assert(entries==0);ack(56);JTC_TurnOrderProcessTick();assert(entries==1&&positions[2].open&&positions[3].open);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};close_ok=false;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0&&held==-1&&g_turn_order_pending_side==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();positions[0].open=true;held=-1;ack(55);JTC_TurnOrderProcessTick();assert(entries==0&&!g_turn_order_flat_confirmed);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};InpTurnReverseOnOpposite=false;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();latest+=180;ack(55);JTC_TurnOrderProcessTick();assert(entries==0&&g_turn_order_pending_side==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();g_auto_trading=false;ack(55);JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};JTC_TurnOrderProcessTick();ack(55);ask=13;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_auto_trading=false;JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpSystemEnabled=false;JTC_TurnOrderProcessTick();InpSystemEnabled=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpTurnPreEnabled=false;JTC_TurnOrderProcessTick();InpTurnPreEnabled=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_signal=false;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();g_assist_state.turn_pre_data_valid=false;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_side=0;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();latest=1180;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();now=1179;JTC_TurnOrderProcessTick();now=1180;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();allowed_side=-1;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};allowed_side=-1;JTC_TurnOrderProcessTick();ack(55);JTC_TurnOrderProcessTick();assert(exits==1&&entries==0);cases++;
 reset();held=-1;permission=false;JTC_TurnOrderProcessTick();assert(exits==0&&entries==0);cases++;
 reset();entry_ok=false;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(entries==1&&held==0&&g_trade_cycle.state==0&&!g_m3_auto_execution_context_active);cases++;
 reset();ask=13;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();ask=10.1;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_trade_cycle.state=JTA_CYCLE_ENTRY_PENDING;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_entry_order_in_progress=true;JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();InpTurnTradeEnabled=false;JTC_TurnOrderProcessTick();assert(entries==0&&exits==0);cases++;
 reset();g_assist_state.turn_pre_atr14=std::nan("");JTC_TurnOrderProcessTick();assert(entries==0);cases++;
 reset();g_assist_state.turn_pre_pivot_price=std::nan("");JTC_TurnOrderProcessTick();assert(entries==0);cases++;

 reset();held=1;g_max_additional_entries=2;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&entries==0&&g_csv_order_signal_source=="TURN_PRE");cases++;
 reset(-1);held=-1;g_max_additional_entries=2;JTC_TurnOrderProcessTick();assert(adds==1);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&entries==0&&g_csv_order_signal_source=="DIRECTION");cases++;
 reset(-1);held=-1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_side=-1;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==1);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&g_csv_order_signal_source=="TURN_PRE");cases++;
 reset();held=-1;positions={{55,"GOLD",123,true}};g_max_additional_entries=2;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;g_assist_state.turn_direction_side=-1;JTC_TurnOrderProcessTick();assert(exits==1&&adds==0);cases++;
 reset();g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0&&entries==0&&exits==0);cases++;
 reset();held=-1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0&&exits==0);cases++;
 reset();held=1;g_max_additional_entries=1;g_additional_entry_filled_count=1;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;add_ok=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();JTC_TurnOrderProcessTick();assert(adds==1&&g_additional_entry_filled_count==0);cases++;
 reset();held=1;g_max_additional_entries=2;bars_since=0;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_add_order_in_progress=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_add_position_sync_pending=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_trade_cycle.state=JTA_CYCLE_EXIT_PENDING;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;allowed_side=-1;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;InpTurnAddOnPre=false;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;InpTurnAddOnDirection=false;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_auto_trading=false;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();g_auto_trading=true;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;latest=1180;JTC_TurnOrderProcessTick();assert(adds==0);cases++;
 reset();held=1;g_max_additional_entries=2;g_assist_state.turn_pre_signal=false;g_assist_state.turn_direction_valid=g_assist_state.turn_direction_signal=true;JTC_TurnOrderProcessTick();assert(adds==1);latest=1180;now=1360;g_assist_state.turn_direction_bar=1180;JTC_TurnOrderProcessTick();assert(adds==2);latest=1360;now=1540;g_assist_state.turn_direction_bar=1360;JTC_TurnOrderProcessTick();assert(adds==2&&g_additional_entry_filled_count==2);cases++;
 std::cout<<cases<<" order-router scenarios passed\n";
}
