from pathlib import Path
import pandas as pd,numpy as np,re,subprocess,json
P=Path(__file__).resolve().parents[1];E=P/'MQL5/Experts/Joon_Trade_Compass_v8_286_TurnAdd'
b=pd.read_csv(P/'analysis/input_bars.csv');epochs=pd.to_datetime(b.m3_bar_time,format='%Y.%m.%d %H:%M:%S').astype('int64')//10**9
pre=pd.read_csv(P/'analysis/turn_divergence.csv');pre_map=dict(zip(pre['index'],pre['side']))
valid=pd.read_csv(P/'analysis/turn_frames.csv').set_index('index')['valid'].to_dict()
# Replay real closed-bar MACD buffer 7 and the original direction progression/OFF->ON rule.
owner=0;leg=-1;active=False;last=-1;refhigh=reflow=0;expected=[];rows=[]
for i,row in b.iterrows():
 ok=bool(valid.get(i,False)) and i>0 and epochs[i]-epochs[i-1]==180
 turn=pre_map.get(i,0);prev=b.iloc[max(0,i-1)]
 rows.append([int(epochs[i]),row.m3_close,prev.m3_close,row.m3_high,prev.m3_high,row.m3_low,prev.m3_low,row.assist_macd_base,prev.assist_macd_base,int(ok),turn])
 if not ok:owner=0;active=False;refhigh=reflow=0;continue
 if turn:owner=turn;leg=i;active=False;last=-1;refhigh=reflow=0;continue
 if not owner or i<=leg:continue
 extension=(last<=leg or (row.m3_close>refhigh if owner>0 else row.m3_close<reflow))
 aligned=extension and ((row.m3_close>prev.m3_close and row.m3_high>prev.m3_high and row.assist_macd_base>prev.assist_macd_base) if owner>0 else (row.m3_close<prev.m3_close and row.m3_low<prev.m3_low and row.assist_macd_base<prev.assist_macd_base))
 if not aligned:active=False;continue
 if active:continue
 active=True;last=i;refhigh=row.m3_high;reflow=row.m3_low;expected.append((int(epochs[i]),owner))
pd.DataFrame(rows).to_csv(P/'tests/direction_input.tsv',sep=' ',index=False,header=False)
core=(E/'TurnDirectionCore.mqh').read_text()
adapter=(E/'TurnDirectionEngine.mqh').read_text();adapter=adapter.replace('#include "TurnDirectionCore.mqh"','');adapter=re.sub(r'const (MqlRates|double) &(\w+)\[\]',r'const std::vector<\1> &\2',adapter)
header=r'''
#include <vector>
#include <string>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <cassert>
using datetime=long long;using string=std::string;
struct MqlRates{datetime time;double open,high,low,close;};
template<class T>void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
double MathMax(double a,double b){return std::max(a,b);}
bool JTC_TurnFinite(double v){return std::isfinite(v)&&v!=1.7976931348623157e308;}
int PERIOD_M3=3,AUTO_TF=3,_Period=3,InpTurnChartHistoryBars=2000;
bool InpTurnPreEnabled=true,InpTurnShowChart=false;long InpMagicNumber=1;string _Symbol="GOLD";double _Point=.01;
int OBJ_ARROW=1,OBJPROP_ARROWCODE=1,OBJPROP_COLOR=2,OBJPROP_SELECTABLE=3,OBJPROP_TOOLTIP=4,clrDeepSkyBlue=1,clrOrange=2,TIME_DATE=1,TIME_SECONDS=2;
string IntegerToString(long n){return std::to_string(n);}string TimeToString(datetime n,int){return std::to_string(n);}
int iBarShift(const string&,int,datetime,bool){return 0;}
int ObjectFind(int,const string&){return -1;}
bool ObjectCreate(int,const string&,int,int,datetime,double){return true;}
void ObjectSetInteger(int,const string&,int,long){}void ObjectSetString(int,const string&,int,const string&){}
struct Assist {bool turn_direction_valid=false,turn_direction_signal=false,turn_pre_data_valid=false,turn_pre_signal=false;int turn_direction_side=0,turn_direction_owner_side=0,turn_pre_side=0;datetime turn_direction_bar=0;string turn_direction_reason;double turn_pre_atr14=1;}g_assist_state;
'''
body=r'''
int main(int argc,char **argv){
 if(argc!=3)return 2;
 JTC_TURN_DIRECTION_STATE s;JTC_TurnDirectionResetState(s);
 auto step=[&](datetime t,bool v,int pre,double c,double pc,double h,double ph,double l,double pl,double m,double pm){return JTC_TurnDirectionDecide(s,t,v,pre,c,pc,h,ph,l,pl,m,pm);};
 assert(step(1000,true,1,10,9,11,10,8,7,1,0)==0);
 assert(step(1180,true,0,11,10,12,11,9,8,2,1)==1);
 assert(step(1180,true,0,11,10,12,11,9,8,2,1)==0);
 assert(step(1360,true,0,13,11,14,12,10,9,3,2)==0); // persistent alignment
 assert(step(1540,true,0,12,13,13,14,9,10,2,3)==0); // FALSE rearms
 assert(step(1720,true,0,15,12,16,13,11,9,4,2)==1); // beyond previous DIRECTION high
 assert(step(1900,false,0,16,15,17,16,12,11,5,4)==0&&s.owner_side==0);
 assert(step(2080,true,0,17,16,18,17,13,12,6,5)==0);
 assert(step(2260,true,-1,15,17,17,18,13,14,3,6)==0);
 assert(step(2440,true,0,13,15,15,17,11,13,2,3)==-1);
 assert(step(2620,true,0,12,13,14,15,10,11,1,2)==0);
 assert(step(2800,true,0,14,12,15,14,12,10,3,1)==0);
 assert(step(2980,true,0,11.5,14,13,15,11.2,12,2,3)==0); // not beyond prior low=11
 assert(step(3160,true,0,10,11.5,12,13,9,11.2,1,2)==-1);
 JTC_TurnDirectionResetState(g_turn_direction_state);
 std::ifstream in(argv[1]);std::ofstream out(argv[2]);out<<"time,side\n";
 datetime t;double c,pc,h,ph,l,pl,m,pm;int v,pre;int n=0,count=0;
 while(in>>t>>c>>pc>>h>>ph>>l>>pl>>m>>pm>>v>>pre){
  std::vector<MqlRates> r={{t+180,999,999,999,999},{t,c,h,l,c},{t-180,pc,ph,pl,pc}};
  std::vector<double> base={999,m,pm};
  g_assist_state.turn_pre_data_valid=v;g_assist_state.turn_pre_signal=pre!=0;g_assist_state.turn_pre_side=pre;
  auto prior=g_turn_direction_state;
  JTC_TurnDirectionProcess(r,base,false);auto result=g_turn_direction_state;
  auto pulse=g_assist_state.turn_direction_signal;auto side=g_assist_state.turn_direction_side;
  // Forming-bar changes cannot alter output or directional memory.
  r[0].close=-888;r[0].high=9999;r[0].low=-9999;base[0]=-99999;g_turn_direction_state=prior;
  JTC_TurnDirectionProcess(r,base,false);
  assert(pulse==g_assist_state.turn_direction_signal&&side==g_assist_state.turn_direction_side);
  assert(result.last_event_time==g_turn_direction_state.last_event_time&&result.active==g_turn_direction_state.active);
  if(pulse){out<<t<<","<<side<<"\n";count++;}n++;
 }
 // Invalid MACD buffer and a discontinuous pair clear ownership and suppress pulses.
 std::vector<MqlRates> r={{4000,0,0,0,0},{3820,12,13,11,12},{3640,11,12,10,11}};
 std::vector<double> base={0,NAN,1};g_assist_state.turn_pre_data_valid=true;g_assist_state.turn_pre_signal=true;g_assist_state.turn_pre_side=1;
 JTC_TurnDirectionResetState(g_turn_direction_state);JTC_TurnDirectionProcess(r,base,false);assert(!g_assist_state.turn_direction_valid&&!g_assist_state.turn_direction_signal);
 base[1]=2;r[2].time-=1;JTC_TurnDirectionResetState(g_turn_direction_state);JTC_TurnDirectionProcess(r,base,false);assert(!g_assist_state.turn_direction_valid);
 std::cout<<n<<" bars, "<<count<<" direction candidates; rearm/symmetry/gap/forming checks passed\n";
}
'''
cpp=P/'tests/direction_tests.cpp';cpp.write_text(header+core+adapter+body)
subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(cpp),'-o',str(P/'tests/direction_tests')],check=True)
r=subprocess.run([str(P/'tests/direction_tests'),str(P/'tests/direction_input.tsv'),str(P/'tests/direction_candidates.csv')],check=True,capture_output=True,text=True);print(r.stdout)
a=pd.read_csv(P/'tests/direction_candidates.csv');assert list(zip(a.time,a.side))==expected
fields=['valid','signal','side','bar','owner_side','reason'];export=(E/'DataExportEngine.mqh').read_text()
assert all('DataExportCsvAdd(header, "turn_direction_'+x+'");' in export for x in fields)
assert len(re.findall(r'DataExportCsvAdd\(row, [^\n]*g_assist_state.turn_direction_',export))==6
assert 'return 634;' in export
r={'bars':len(b),'direction_candidates':len(a),'long':int((a.side==1).sum()),'short':int((a.side==-1).sum()),'actual_core_and_adapter_vs_reference_match':True,'forming_mutation_all_bars':True,'csv_columns':634,'csv_new_direction_fields':fields,'MT5_compile':'NOT_RUN','MT5_backtest':'NOT_RUN','candidates_are_not_executed_ADD_orders':True}
(P/'tests/direction_validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
