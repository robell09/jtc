
#include <vector>
#include <string>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <cassert>
using datetime=long long;using string=std::string;
struct MqlRates{datetime time;double open,high,low,close;};
template<class T>void ZeroMemory(T &v){std::memset(&v,0,sizeof(v));}
template<class T>int ArraySize(const std::vector<T>&v){return v.size();}
double MathMax(double a,double b){return std::max(a,b);}
bool JTC_TurnFinite(double v){return std::isfinite(v)&&v!=1.7976931348623157e308;}
int PERIOD_M3=3,AUTO_TF=3,_Period=3,InpTurnChartHistoryBars=2000;
bool InpTurnPreEnabled=true,InpTurnShowChart=false;long InpMagicNumber=1;string _Symbol="GOLD";double _Point=.01;
int OBJ_ARROW=1,OBJPROP_ARROWCODE=1,OBJPROP_COLOR=2,OBJPROP_SELECTABLE=3,OBJPROP_TOOLTIP=4,clrDeepSkyBlue=1,clrOrange=2,TIME_DATE=1,TIME_SECONDS=2;
string IntegerToString(long n){return std::to_string(n);}string TimeToString(datetime n,int){return std::to_string(n);}
int iBarShift(const string&,int,datetime,bool){return 0;}
int ObjectFind(int,const string&){return -1;}
bool ObjectCreate(int,const string&,int,int,datetime,double){return true;}
void ObjectSetInteger(int,const string&,int,long){}void ObjectSetString(int,const string&,int,const string&){}
struct Assist {bool turn_direction_valid=false,turn_direction_signal=false,turn_pre_data_valid=false,turn_pre_signal=false;int turn_direction_side=0,turn_direction_owner_side=0,turn_pre_side=0;datetime turn_direction_bar=0;string turn_direction_reason;double turn_pre_atr14=1;}g_assist_state;
#ifndef JTC_TURN_DIRECTION_CORE_MQH
#define JTC_TURN_DIRECTION_CORE_MQH
// Existing SIMPLE_DIRECTION price/MACD-base progress and OFF->ON rule.
// The leg owner is now a confirmed TURN PRE, rather than a legacy WATCH.
struct JTC_TURN_DIRECTION_STATE
{
   datetime last_bar,leg_time,last_event_time;
   int owner_side;
   bool active;
   double prior_high,prior_low;
};
void JTC_TurnDirectionResetState(JTC_TURN_DIRECTION_STATE &s)
{
   ZeroMemory(s);
}
int JTC_TurnDirectionDecide(JTC_TURN_DIRECTION_STATE &s,const datetime bar,
   const bool valid,const int new_turn_side,const double close1,const double close2,
   const double high1,const double high2,const double low1,const double low2,
   const double base1,const double base2)
{
   if(bar<=0 || bar<=s.last_bar) return 0;
   s.last_bar=bar;
   if(!valid)
   {s.owner_side=0;s.leg_time=0;s.active=false;s.prior_high=0.0;s.prior_low=0.0;return 0;}
   if(new_turn_side==1 || new_turn_side==-1)
   {
      s.owner_side=new_turn_side;s.leg_time=bar;s.active=false;
      s.last_event_time=0;s.prior_high=0.0;s.prior_low=0.0;
      return 0; // PRE has priority; no DIRECTION on the same owner bar.
   }
   if(s.owner_side==0 || bar<=s.leg_time) return 0;
   const bool prior=s.last_event_time>s.leg_time;
   const bool aligned=s.owner_side>0 ?
      close1>close2 && high1>high2 && base1>base2 && (!prior || close1>s.prior_high) :
      close1<close2 && low1<low2 && base1<base2 && (!prior || close1<s.prior_low);
   if(!aligned) {s.active=false;return 0;}
   if(s.active) return 0;
   s.active=true;s.last_event_time=bar;s.prior_high=high1;s.prior_low=low1;
   return s.owner_side;
}
#endif
#ifndef JTC_TURN_DIRECTION_ENGINE_MQH
#define JTC_TURN_DIRECTION_ENGINE_MQH

JTC_TURN_DIRECTION_STATE g_turn_direction_state;
void JTC_TurnDirectionProcess(const std::vector<MqlRates> &r,const std::vector<double> &base,
                              const bool historical_replay)
{
   g_assist_state.turn_direction_valid=false;
   g_assist_state.turn_direction_signal=false;
   g_assist_state.turn_direction_side=0;
   g_assist_state.turn_direction_bar=0;
   g_assist_state.turn_direction_owner_side=g_turn_direction_state.owner_side;
   g_assist_state.turn_direction_reason="NOT_READY";
   if(!InpTurnPreEnabled || AUTO_TF!=PERIOD_M3 || ArraySize(r)<3 || ArraySize(base)<3) return;
   const datetime bar=r[1].time;
   const bool valid=g_assist_state.turn_pre_data_valid && r[1].time-r[2].time==180 &&
      JTC_TurnFinite(base[1]) && JTC_TurnFinite(base[2]);
   const int owner=g_assist_state.turn_pre_signal ? g_assist_state.turn_pre_side : 0;
   const int side=JTC_TurnDirectionDecide(g_turn_direction_state,bar,valid,owner,
      r[1].close,r[2].close,r[1].high,r[2].high,r[1].low,r[2].low,base[1],base[2]);
   g_assist_state.turn_direction_valid=valid;
   g_assist_state.turn_direction_signal=(side!=0);
   g_assist_state.turn_direction_side=side;
   g_assist_state.turn_direction_bar=bar;
   g_assist_state.turn_direction_owner_side=g_turn_direction_state.owner_side;
   g_assist_state.turn_direction_reason=!valid ? "INVALID_OR_GAP" :
      (owner!=0 ? "TURN_LEG_START" : (side!=0 ? "DIRECTION_OFF_ON_PROGRESS" : "NO_NEW_DIRECTION"));
   if(side==0 || !InpTurnShowChart || _Period!=PERIOD_M3 ||
      (historical_replay && iBarShift(_Symbol,PERIOD_M3,bar,false)>InpTurnChartHistoryBars)) return;
   const string name="JTC_TURN284_EA_"+IntegerToString((long)InpMagicNumber)+"_DIR_"+IntegerToString((long)bar);
   const double offset=MathMax(_Point*10.0,g_assist_state.turn_pre_atr14*0.25);
   if(ObjectFind(0,name)<0 && ObjectCreate(0,name,OBJ_ARROW,0,bar,side>0 ? r[1].low-offset : r[1].high+offset))
   {
      ObjectSetInteger(0,name,OBJPROP_ARROWCODE,side>0 ? 241 : 242);
      ObjectSetInteger(0,name,OBJPROP_COLOR,side>0 ? clrDeepSkyBlue : clrOrange);
      ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
      ObjectSetString(0,name,OBJPROP_TOOLTIP,"TURN DIRECTION ADD CANDIDATE | AVAILABLE AFTER "+TimeToString(bar+180,TIME_DATE|TIME_SECONDS));
   }
}
#endif

int main(int argc,char **argv){
 if(argc!=3)return 2;
 JTC_TURN_DIRECTION_STATE s;JTC_TurnDirectionResetState(s);
 auto step=[&](datetime t,bool v,int pre,double c,double pc,double h,double ph,double l,double pl,double m,double pm){return JTC_TurnDirectionDecide(s,t,v,pre,c,pc,h,ph,l,pl,m,pm);};
 assert(step(1000,true,1,10,9,11,10,8,7,1,0)==0);
 assert(step(1180,true,0,11,10,12,11,9,8,2,1)==1);
 assert(step(1180,true,0,11,10,12,11,9,8,2,1)==0);
 assert(step(1360,true,0,13,11,14,12,10,9,3,2)==0); // persistent alignment
 assert(step(1540,true,0,12,13,13,14,9,10,2,3)==0); // FALSE rearms
 assert(step(1720,true,0,15,12,16,13,11,9,4,2)==1); // beyond previous DIRECTION high
 assert(step(1900,false,0,16,15,17,16,12,11,5,4)==0&&s.owner_side==0);
 assert(step(2080,true,0,17,16,18,17,13,12,6,5)==0);
 assert(step(2260,true,-1,15,17,17,18,13,14,3,6)==0);
 assert(step(2440,true,0,13,15,15,17,11,13,2,3)==-1);
 assert(step(2620,true,0,12,13,14,15,10,11,1,2)==0);
 assert(step(2800,true,0,14,12,15,14,12,10,3,1)==0);
 assert(step(2980,true,0,11.5,14,13,15,11.2,12,2,3)==0); // not beyond prior low=11
 assert(step(3160,true,0,10,11.5,12,13,9,11.2,1,2)==-1);
 JTC_TurnDirectionResetState(g_turn_direction_state);
 std::ifstream in(argv[1]);std::ofstream out(argv[2]);out<<"time,side\n";
 datetime t;double c,pc,h,ph,l,pl,m,pm;int v,pre;int n=0,count=0;
 while(in>>t>>c>>pc>>h>>ph>>l>>pl>>m>>pm>>v>>pre){
  std::vector<MqlRates> r={{t+180,999,999,999,999},{t,c,h,l,c},{t-180,pc,ph,pl,pc}};
  std::vector<double> base={999,m,pm};
  g_assist_state.turn_pre_data_valid=v;g_assist_state.turn_pre_signal=pre!=0;g_assist_state.turn_pre_side=pre;
  auto prior=g_turn_direction_state;
  JTC_TurnDirectionProcess(r,base,false);auto result=g_turn_direction_state;
  auto pulse=g_assist_state.turn_direction_signal;auto side=g_assist_state.turn_direction_side;
  // Forming-bar changes cannot alter output or directional memory.
  r[0].close=-888;r[0].high=9999;r[0].low=-9999;base[0]=-99999;g_turn_direction_state=prior;
  JTC_TurnDirectionProcess(r,base,false);
  assert(pulse==g_assist_state.turn_direction_signal&&side==g_assist_state.turn_direction_side);
  assert(result.last_event_time==g_turn_direction_state.last_event_time&&result.active==g_turn_direction_state.active);
  if(pulse){out<<t<<","<<side<<"\n";count++;}n++;
 }
 // Invalid MACD buffer and a discontinuous pair clear ownership and suppress pulses.
 std::vector<MqlRates> r={{4000,0,0,0,0},{3820,12,13,11,12},{3640,11,12,10,11}};
 std::vector<double> base={0,NAN,1};g_assist_state.turn_pre_data_valid=true;g_assist_state.turn_pre_signal=true;g_assist_state.turn_pre_side=1;
 JTC_TurnDirectionResetState(g_turn_direction_state);JTC_TurnDirectionProcess(r,base,false);assert(!g_assist_state.turn_direction_valid&&!g_assist_state.turn_direction_signal);
 base[1]=2;r[2].time-=1;JTC_TurnDirectionResetState(g_turn_direction_state);JTC_TurnDirectionProcess(r,base,false);assert(!g_assist_state.turn_direction_valid);
 std::cout<<n<<" bars, "<<count<<" direction candidates; rearm/symmetry/gap/forming checks passed\n";
}
